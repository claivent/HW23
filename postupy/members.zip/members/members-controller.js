"use strict";
const MembersAbl = require("../../abl/members-abl");

class MembersController {

  init(ucEnv) {
    return MembersAbl.init(
      ucEnv.getUri().getAwid(),
      ucEnv.getDtoIn(),
      ucEnv.getSession(),
      ucEnv.getAuthorizationResult()
    );
  }

}

module.exports = new MembersController();
