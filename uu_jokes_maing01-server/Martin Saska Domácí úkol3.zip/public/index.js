/*!
 * UAF COMMERCIAL LICENSE
 * ----------------------
 * 1. PREAMBLE and Definitions
 *   1.1 These UAF Commercial License Terms ("UAF CLT") govern licensing of the Unicorn Application Framework (UAF).
 *     The Customer and Unicorn concluded an agreement for the provision of Solution that is using UAF or its parts
 *     (the "Agreement").
 *   1.2 The provisions of these UAF CLT shall govern the relationship between the Customer and Unicorn regarding
 *     the UAF License granted under the Agreement. For the avoidance of doubt, in case of any conflict between these
 *     UAF CLT and the Agreement, the provisions of the Agreement always prevail.
 *   1.3 The "UAF Components", and each of them individually as "UAF Component", shall mean the components of the Unicorn
 *     Application Framework, which are listed and described in the Attachment I to these UAF CLT.
 *   1.4 "UAF" shall mean the Unicorn Application Framework the scope of which is described in Attachment I, including all
 *     associated documentation and preparatory design materials, in particular blueprints, models, user manuals,
 *     training materials, comprehensive instructions and guidelines for drafting, production, operation and maintenance of
 *     software solutions, reference architecture, ready-made components and tools, use cases and tutorials.
 *   1.5 The "Knowledge Base" shall mean the online materials, internet fora and other resources made available by Unicorn
 *     online with regard to the UAF, intended for the broad customer and developer community.
 *   1.6 The "License" shall mean the binding terms and conditions for use of the UAF by the Customer. The License is
 *     described in Clause 2 and may be further specified or modified by the Agreement.
 *   1.7 The "Solution" shall mean any product or service developed under the Agreement using the UAF or any of
 *     UAF Components or its other parts, further specified in the Agreement.
 * 2. LICENSE GRANT
 *   2.1 The Customer shall be hereby granted a non-exclusive and non-transferable worldwide license to use the UAF for
 *     the purpose of the Solution described in the Agreement. For this purpose, the Customer shall be entitled to modify
 *     the UAF and create derivative works based on the UAF.
 *   2.2 The Customer is entitled to grant third parties a sub-license allowing them to use the UAF or any derivative works
 *     based on the UAF under commercial terms of its choice, provided that:
 *     2.2.1 use of the UAF and any derivative works based on the UAF by third parties is limited to testing, handover and
 *       operation of the Solution or its use as a service,
 *     2.2.2 third parties are not entitled to use the UAF or any derivative works based on the UAF independently of
 *       the Solution,
 *     2.2.3 third parties are not provided access to source code of the UAF unless such right is granted by the Agreement
 *       or if they conclude a commercial license agreement with Unicorn.
 *   2.3 The Solution or its parts based on the UAF shall bear a prominent copyright notice "Based on Unicorn Application
 *     Framework Copyright (c) Unicorn" integrated
 *     2.3.1 in the graphical user interface of the Solution or its relevant part or
 *     2.3.2 in accompanying file if the Solution or its relevant part do not have graphical user interface or
 *     2.3.3 in Solution's documentation.
 *   2.4 The License shall be valid for the whole duration of copyright to the UAF, unless other duration of the License is
 *     specified in the Agreement.
 *   2.5 The Customer is entitled to access the Knowledge Base only if expressly agreed in the Agreement.
 *   2.6 The Unicorn retains all rights to the UAF not covered by the provisions of this Clause 2. Unless explicitly
 *     permitted by applicable law, the Customer may not use the UAF in any other way than provided by the provisions of
 *     this Clause 2 and may not allow such use on its behalf by any of its employees or agents.
 *   2.7 The price for the License is included in the price stipulated in the Agreement.
 * 3. MODIFICATIONS
 *   3.1 The Customer explicitly acknowledges that the UAF is under continuous development and any UAF Component or other
 *     part of the UAF may be modified, replaced or removed by the Unicorn from the UAF in any of its future versions.
 *   3.2 This License covers also any new version of UAF if some parts of the UAF are modified or replaced.
 *   3.3 If any part of the UAF is removed by Unicorn in any of its future versions, the License for such version of
 *     the UAF is reduced appropriately and covers only the remaining parts of UAF. Sub-licenses previously granted to
 *     third parties in accordance with Clause 2.2 remain unaffected.
 * 4. THIRD PARTY LICENSE TERMS
 *   4.1 UAF is using third party software tools (the "Third Party Software") that is an integral part of the UAF. Some of
 *     these tools are free software or open-source SW.
 *   4.2 The list of Third Party Software used in the UAF including its license terms and authors is provided as part of
 *     Attachment I to these UAF CLT.
 *   4.3 For the use of the above mentioned Third Party Software, the Customer acknowledges its license terms referred to
 *     in Attachment I to these UAF CLT.
 * 5. NO TRADEMARK OR PATENT LICENSE
 *   5.1 These UAF CLT cover only copyright use of the UAF. If not expressly agreed otherwise, the Customer shall not be
 *     granted any trademark and/or patent license here under and nothing in these UAF CLT shall be interpreted in a way it
 *     does so.
 * 6. LIMITED WARRANTY
 *   6.1 IF NOT STIPULATED OTHER WISE OR REQUIRED BY APPLICABLE LAW, THE UAF IS PROVIDED ON "AS IS" BASIS,
 *     WITH NO WARRANTY OF, INCLUDING WITHOUT LIMITATION, MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE ENTIRE
 *     RISK AS TO THE QUALITY AND PERFORMANCE OF THE UAF IS CARRIED SOLELY BY THE CUSTOMER, UNLESS OTHERWISE AGREED BETWEEN
 *     THE UNICORN AND THE CUSTOMER IN THE AGREEMENT.
 * 7. LIMITATION OF LIABILITY
 *   7.1 TO THE EXTENT PERMITTED BY APPLICABLE LAW, THE UNICORN WILL NOT BE HELD LIABLE FOR ANY DAMAGES CAUSED BY
 *     THE DISTRIBUTION OR USE OF THE UAF. THIS ALSO INCLUDES ANY CONSEQUENTIAL AND/OR INCIDENTAL DAMAGES, MONETARY OR NOT,
 *     THAT ARE CONNECTED WITH THE DISTRIBUTION OR USE OF THE UAF, UNLESS OTHERWISE AGREED BETWEEN THE UNICORN AND
 *     THE CUSTOMER IN THE AGREEMENT.
 * 8. THIRD PARTY CLAIMS
 *   8.1 The Unicorn will defend or settle, at its option and expense, any action brought against the Customer in a member
 *     state of the European Union which concerns an allegation that the UAF provided infringes a patent or copyright or
 *     misappropriates a trade secret in such jurisdiction. The Unicorn shall pay costs and damages finally awarded against
 *     the Customer that are attributable to such action. The Customer declares to understand and agrees that following
 *     conditions must be fulfilled in order to make Unicorn's obligations under this Clause 8 effective and enforceable:
 *     The Customer must (a) notify Unicorn promptly in writing of the action or any reasonable threat of it,
 *     (b) provide the Unicorn with all reasonable information and assistance it will request to settle or defend the action, and
 *     (c) grant the Unicorn sole authority and control of the defense or settlement of the action.
 *   8.2 If a claim is made under Clause 8.1 the Unicorn may, at its sole option and expense:
 *     (a) replace or modify the UAF so that it becomes non-infringing,
 *     (b) procure for the Customer the right to continue using the UAF unmodified.
 *   8.3 The Unicorn shall not be held liable to the Customer if the action is based on:
 *     (a) the combination of UAF with any product not provided by Unicorn,
 *     (b) the modification of the UAF other than by Unicorn,
 *     (c) the use of other than a current unaltered release of the UAF,
 *     (d) a product that the Customer makes, uses, or sells,
 *     (e) infringement by the Customer that is deemed willful. In the case under (e) the Customer shall reimburse
 *     the Unicorn for its reasonable attorney fees and other costs related to the action.
 *   8.4 THIS CLAUSE IS SUBJECT TO CLAUSE 7 AND STATES UNICORN'S ENTIRE LIABILITY, CUSTOMER'S SOLE AND EXCLUSIVE REMEDY,
 *     FOR DEFENSE, SETTLEMENT AND DAMAGES, WITH RESPECT TO ANY ALLEGED PATENT OR COPYRIGHT INFRINGEMENT OR TRADE SECRET
 *     MISAPPROPRIATION BY ANY ITEM PROVIDED UNDER THESE TERMS, UNLESS OTHERWISE AGREEMENT BETWEEN UNICORN AND THE CUSTOMER
 *     IN THE AGREEMENT.
 * 9. GENERAL PROVISIONS
 *   9.1 By entering into the Agreement, the Customer signifies its assent to and acceptance of these UAF CLT.
 *   9.2 The License is effective from the moment of execution of the Agreement, if the Agreement does not specify later
 *     date. Where the provisions of the Agreement regarding the License and provisions of these UAF CLT differ, provisions
 *     of the Agreement shall prevail.
 *   9.3 If any provision of the Agreement regarding the License or these UAF CLT is held by a court of competent
 *     jurisdiction to be void, invalid, unenforceable or illegal, such provision shall be severed from the Agreement or
 *     these UAF CLT and the remaining provisions will remain in full force and effect.
 *   9.4 The provisions of Clauses 7 and 8 shall survive any expiration or termination of the Agreement.
 *   9.5 All rights and obligations between the Unicorn and the Customer arising on the basis of these UAF CLT or
 *     in connection with them are governed by the laws of the Czech Republic with the exclusion of both the rules on
 *     the conflict of laws and the United Nations Convention on Contracts for the International Sale of Goods (CISG).
 *   9.6 The resolution of all disputes arising from or connected here to shall be under sole jurisdiction of the courts of
 *     the Czech Republic.
 */
!function(e,t){
"object"==typeof exports&&"object"==typeof module?module.exports=t(require("module"),require("uu5g05"),require("uu5g04"),require("uu_plus4u5g02"),require("uu5g05-elements"),require("uu_plus4u5g02-app"),require("uu_plus4u5g02-elements"),require("uu5g05-forms"),require("uu5tilesg02"),require("uu5tilesg02-elements"),require("uu5tilesg02-controls"),require("react")):"function"==typeof define&&define.amd?define("index",["module","uu5g05","uu5g04","uu_plus4u5g02","uu5g05-elements","uu_plus4u5g02-app","uu_plus4u5g02-elements","uu5g05-forms","uu5tilesg02","uu5tilesg02-elements","uu5tilesg02-controls","react"],t):"object"==typeof exports?exports.index=t(require("module"),require("uu5g05"),require("uu5g04"),require("uu_plus4u5g02"),require("uu5g05-elements"),require("uu_plus4u5g02-app"),require("uu_plus4u5g02-elements"),require("uu5g05-forms"),require("uu5tilesg02"),require("uu5tilesg02-elements"),require("uu5tilesg02-controls"),require("react")):e.index=t(e[void 0],e.uu5g05,e.uu5g04,e.uu_plus4u5g02,e["uu5g05-elements"],e["uu_plus4u5g02-app"],e["uu_plus4u5g02-elements"],e["uu5g05-forms"],e.uu5tilesg02,e["uu5tilesg02-elements"],e["uu5tilesg02-controls"],e.react)
}(this,((e,t,n,s,i,r,a,l,o,u,c,m)=>(()=>{var p,d,g,U={669:(e,t,n)=>{"use strict";n.d(t,{ZP:()=>a});var s=n(94);const[i,r]=s.Utils.Context.create(),a=i},899:(e,t,n)=>{"use strict";n.d(t,{Z:()=>l})
;var s=n(94),i=n(763),r=n.n(i);const a={call:async(e,t,n,s)=>(await r().Utils.AppClient[e](t,n,s)).data,deleteSlist(e){console.log("Calls delete",e);const t=a.getCommandUri("slist/delete")
;return a.call("post",t)},createSlist(e){console.log("Calls create",e);const t=a.getCommandUri("slist/create");return a.call("post",t)},loadSlistsList(e){const t=a.getCommandUri("slist/list")
;return a.call("get",t)},loadMokSys(e){const t=a.getCommandUri("slist/mokSys");return a.call("get",t)},loadIdentityProfiles(){const e=a.getCommandUri("sys/uuAppWorkspace/initUve")
;return a.call("get",e)},initWorkspace(e){const t=a.getCommandUri("sys/uuAppWorkspace/init");return a.call("post",t,e)},getWorkspace(){const e=a.getCommandUri("sys/uuAppWorkspace/get")
;return a.call("get",e)},initAndGetWorkspace:async e=>(await a.initWorkspace(e),await a.getWorkspace()),Slists:{load(e){const t=a.getCommandUri("sys/uuAppWorkspace/load");return a.call("get",t,e)}},
getCommandUri:(e,t=s.Environment.appBaseUri)=>(t.endsWith("/")?t:t+"/")+(e.startsWith("/")?e.slice(1):e)},l=a},12:(e,t,n)=>{"use strict";n.d(t,{Z:()=>r});var s=n(94);const i="UuJokes.",r={TAG:i,
Css:s.Utils.Css.createCssModule(i.replace(/\.$/,"").toLowerCase().replace(/\./g,"-").replace(/[^a-z-]/g,""),"uu_jokes_maing01-hi/uu_jokes_maing01-hi@0.1.0")}},640:(e,t,n)=>{"use strict";n.d(t,{Z:()=>a
});var s=n(94),i=n(12);const r=i.Z.TAG+"Core.",a={...i.Z,TAG:r,
Css:s.Utils.Css.createCssModule(r.replace(/\.$/,"").toLowerCase().replace(/\./g,"-").replace(/[^a-z-]/g,""),"uu_jokes_maing01-hi/uu_jokes_maing01-hi@0.1.0")}},873:(e,t,n)=>{"use strict";n.d(t,{Z:()=>m
});var s=n(119),i=n.n(s),r=n(94),a=n(781),l=n.n(a),o=n(640),u=n(426),c=(n(763),n(669));const m=(0,r.createVisualComponent)({uu5Tag:o.Z.TAG+"RouteBar",propTypes:{},defaultProps:{},render(e){
const[,t]=(0,r.useRoute)(),n=(0,r.useContext)(c.ZP),s=[{children:Uu5g05.Utils.Element.create(r.Lsi,{import:u.Z,path:["Menu","slists"]}),onClick:()=>t("slists")},{
children:Uu5g05.Utils.Element.create(r.Lsi,{import:u.Z,path:["Menu","about"]}),onClick:()=>t("about"),collapsed:!0}];return Uu5g05.Utils.Element.create(l().RouteBar,i()({appActionList:s
},e),Uu5g05.Utils.Element.create(l().RouteHeader,{title:n.data.data.name}))}})},187:(e,t,n)=>{"use strict";n.r(t),n.d(t,{render:()=>Be});var s=n(602),i=n(94),r=(n(918),
n(899)),a=n(834),l=n.n(a),o=n(763),u=n.n(o),c=n(781),m=n.n(c),p=n(923),d=n.n(p),g=n(12);const U=g.Z.TAG+"Bricks.",h={...g.Z,TAG:U,
Css:i.Utils.Css.createCssModule(U.replace(/\.$/,"").toLowerCase().replace(/\./g,"-").replace(/[^a-z-]/g,""),"uu_jokes_maing01-hi/uu_jokes_maing01-hi@0.1.0")},f=h.TAG+"Slists.",E={...h,TAG:f,
Css:i.Utils.Css.createCssModule(f.replace(/\.$/,"").toLowerCase().replace(/\./g,"-").replace(/[^a-z-]/g,""),"uu_jokes_maing01-hi/uu_jokes_maing01-hi@0.1.0")};var v=n(669);const C=(0,
i.createComponent)({uu5Tag:E.TAG+"Provider",propTypes:{},defaultProps:{},render(e){const t=(0,i.useDataObject)({handlerMap:{load:r.Z.Slists.load}});return Uu5g05.Utils.Element.create(v.ZP.Provider,{
value:t},"function"==typeof e.children?e.children(t):e.children)}});var b=n(640),k=n(24);const y=({screenSize:e})=>h.Css.css({display:"flex",maxWidth:624,padding:"24px 0",margin:"0 auto",
flexWrap:"wrap",..."xs"===e?{justifyContent:"center",textAlign:"center"}:null}),S=()=>h.Css.css({padding:"0 24px"}),T=({screenSize:e})=>h.Css.css({flex:1,minWidth:"xs"===e?"100%":0}),x=(0,
i.createVisualComponent)({uu5Tag:h.TAG+"WelcomeRow",propTypes:{left:i.PropTypes.node},defaultProps:{left:void 0},render(e){const{left:t,children:n}=e,[s]=(0,
i.useScreenSize)(),r=i.Utils.VisualComponent.getAttrs(e,y({screenSize:s}));return Uu5g05.Utils.Element.create("div",r,Uu5g05.Utils.Element.create("div",{className:S({screenSize:s})
},t),Uu5g05.Utils.Element.create("div",{className:T({screenSize:s})},n))}});var _=n(873),A=n(426);const L=()=>k.Z.Css.css({fontSize:48,lineHeight:"1em"});let w=(0,i.createVisualComponent)({
uu5Tag:k.Z.TAG+"Home",propTypes:{},defaultProps:{},render(e){const{identity:t}=(0,i.useSession)(),n=i.Utils.VisualComponent.getAttrs(e)
;return Uu5g05.Utils.Element.create("div",n,Uu5g05.Utils.Element.create(_.Z,null),Uu5g05.Utils.Element.create(x,{left:Uu5g05.Utils.Element.create(d().PersonPhoto,{size:"xl",borderRadius:"none"})
},Uu5g05.Utils.Element.create(l().Text,{category:"story",segment:"heading",type:"h2"},Uu5g05.Utils.Element.create(i.Lsi,{import:A.Z,path:["Home","welcome"]})),t&&Uu5g05.Utils.Element.create(l().Text,{
category:"story",segment:"heading",type:"h2"},t.name)),Uu5g05.Utils.Element.create(x,{left:Uu5g05.Utils.Element.create(l().Icon,{icon:"mdi-human-greeting",className:L()})
},Uu5g05.Utils.Element.create(l().Text,{category:"story",segment:"body",type:"common"},Uu5g05.Utils.Element.create(i.Lsi,{import:A.Z,path:["Home","intro"]}))),Uu5g05.Utils.Element.create(x,{
left:Uu5g05.Utils.Element.create(l().Icon,{icon:"mdi-monitor",className:L()})},Uu5g05.Utils.Element.create(l().Text,{category:"story",segment:"body",type:"common"},Uu5g05.Utils.Element.create(i.Lsi,{
import:A.Z,path:["Home","clientSide"]}))),Uu5g05.Utils.Element.create(x,{left:Uu5g05.Utils.Element.create(l().Icon,{icon:"mdi-server",className:L()})},Uu5g05.Utils.Element.create(l().Text,{
category:"story",segment:"body",type:"common"},Uu5g05.Utils.Element.create(i.Lsi,{import:A.Z,path:["Home","serverSide"]}))))}});w=(0,c.withRoute)(w,{authenticated:!0});const P=w,j=h.TAG+"Help.",N={
...h,TAG:j,Css:i.Utils.Css.createCssModule(j.replace(/\.$/,"").toLowerCase().replace(/\./g,"-").replace(/[^a-z-]/g,""),"uu_jokes_maing01-hi/uu_jokes_maing01-hi@0.1.0")
},I=()=>N.Css.css({}),z=()=>N.Css.css({fontSize:30,lineHeight:"1em",display:"block"}),M=()=>N.Css.css({marginLeft:"10px"}),B=()=>N.Css.css({marginLeft:"40px"}),Z=()=>N.Css.css({marginLeft:"40px"
}),G=(0,i.createVisualComponent)({uu5Tag:N.TAG+"Tree",nestingLevel:["areaCollection","area"],propTypes:{},defaultProps:{},render(e){
const{children:t}=e,n=i.Utils.VisualComponent.getAttrs(e,I()),s=i.Utils.NestingLevel.getNestingLevel(e,G)
;return s?Uu5g05.Utils.Element.create("div",n,Uu5g05.Utils.Element.create("div",null,"Visual Component ",G.uu5Tag),Uu5g05.Utils.Element.create(i.Content,{nestingLevel:s
},t,Uu5g05.Utils.Element.create("ul",{className:z()+" "+M()}," MainBox",Uu5g05.Utils.Element.create("ul",{className:B()
},"TopBar",Uu5g05.Utils.Element.create("li",null,"SearchBar")),Uu5g05.Utils.Element.create("ul",{className:B()
},"SListBar (list of lists)",Uu5g05.Utils.Element.create("li",null,"CategoryRow"),Uu5g05.Utils.Element.create("li",null,"Item (list)"),Uu5g05.Utils.Element.create("li",null,"SBtnBox"),Uu5g05.Utils.Element.create("ul",{
className:Z()
},"SListBar   (list of Items)",Uu5g05.Utils.Element.create("li",null,"CategoryRow"),Uu5g05.Utils.Element.create("li",null,"Item (list)"),Uu5g05.Utils.Element.create("li",null,"SBtnBox"))),Uu5g05.Utils.Element.create("ul",{
className:B()},"Footbar",Uu5g05.Utils.Element.create("li",null,"RouteBar"))))):null}});var V=n(119),O=n.n(V);const W=h.TAG+"Slist.",q={...h,TAG:W,
Css:i.Utils.Css.createCssModule(W.replace(/\.$/,"").toLowerCase().replace(/\./g,"-").replace(/[^a-z-]/g,""),"uu_jokes_maing01-hi/uu_jokes_maing01-hi@0.1.0")};var D=n(389),R=n.n(D)
;const F=()=>q.Css.css({}),H=(0,i.createVisualComponent)({uu5Tag:q.TAG+"SearchBar",propTypes:{},defaultProps:{},render(e){const{children:t}=e;i.Utils.VisualComponent.getAttrs(e,F())
;return Uu5g05.Utils.Element.create(R().Form,null,Uu5g05.Utils.Element.create(R().Checkbox,{label:"Show only active items",value:e.isChecked,onChange:e.onShow}))}}),$=()=>q.Css.css({}),J=e=>{let t
;switch(e){case"xs":case"s":t="100%";break;case"m":case"l":t=640;break;default:t=1280}return q.Css.css({maxWidth:t,margin:"0px auto",paddingLeft:8,paddingRight:8})},K=(0,i.createVisualComponent)({
uu5Tag:q.TAG+"SItem",propTypes:{},defaultProps:{},render(e){const{children:t}=e,[n,s]=(0,i.useState)(e.product.name),[r,a]=(0,i.useState)(e.product.amount),[o,u]=(0,
i.useState)(e.product.unit),c=e.product.active;const m=i.Utils.VisualComponent.getAttrs(e,$());return console.log(e.product),Uu5g05.Utils.Element.create(l().ListItem,O()({},m,{icon:"uugds-dnd",
actionList:[{icon:"uugds-delete",primary:!0,onClick:e.onDelete}]}),Uu5g05.Utils.Element.create(R().Text.Input,{value:n,onChange:e=>s(e.data.value),placeholder:"Vlož jméno",significance:"distinct",
className:J(i.useScreenSize)}),Uu5g05.Utils.Element.create(R().Text.Input,{value:r,onChange:e=>a(e.data.value),placeholder:"Množství",significance:"distinct",className:J(i.useScreenSize)
}),Uu5g05.Utils.Element.create(R().Text.Input,{value:o,onChange:e=>u(e.data.value),placeholder:"Jednotka množství",significance:"distinct",className:J(i.useScreenSize)
}),Uu5g05.Utils.Element.create(R().Checkbox,{value:c,box:c,name:"active",label:"nakoupeno",onChange:t=>{!function(t,n){e.isItemActive(t,n)}(e.product.id,t.data.value)},className:J(i.useScreenSize)}))}
});var Y=n(767),Q=n.n(Y),X=n(320),ee=n.n(X);const te=()=>q.Css.css({}),ne=()=>q.Css.css({margin:"24px 0px",border:"2px solid black"}),se=(0,i.createVisualComponent)({uu5Tag:q.TAG+"SItems",
propTypes:{},defaultProps:{},render(e){const{children:t}=e,n=e.products;i.Utils.VisualComponent.getAttrs(e,te());return console.log("Products",e.products,e.isActive),
Uu5g05.Utils.Element.create(l().Grid.Item,null,n.filter((t=>!e.isActive||!t.active)).map((t=>Uu5g05.Utils.Element.create(K,{className:ne(),key:t.id,product:t,onDelete:()=>{return n=t.id,
void e.onDelete(n);var n},isItemActive:e.isItemActive}))))}}),ie=()=>q.Css.css({}),re=(0,i.createVisualComponent)({uu5Tag:q.TAG+"Footbar",propTypes:{},defaultProps:{},render(e){
const{children:t}=e,n=i.Utils.VisualComponent.getAttrs(e,ie());return Uu5g05.Utils.Element.create("div",n)}}),ae=()=>q.Css.css({BackgroundColor:"grey"}),le=e=>{let t;switch(e){case"xs":case"s":
t="100%";break;case"m":case"l":t=640;break;default:t=1280}return q.Css.css({maxWidth:t,margin:"0px auto",paddingLeft:8,paddingRight:8})},oe=(0,i.createVisualComponent)({uu5Tag:q.TAG+"MainBox",
propTypes:{},defaultProps:{},render(e){const{children:t}=e,[n,s]=(0,i.useState)(!1),[r,a]=(0,i.useState)(e.initialProducts),[o,u]=(0,i.useState)(e.initialList),[c,m]=(0,i.useState)([!1,0])
;const p=i.Utils.VisualComponent.getAttrs(e,ae()),[d]=(0,i.useScreenSize)();return Uu5g05.Utils.Element.create("div",{className:le(d)},Uu5g05.Utils.Element.create(l().Block,{header:o.name,
headerType:"title",actionList:[{icon:"uugds-pencil",onClick:()=>m([!0,0])}]},Uu5g05.Utils.Element.create(l().Block,O()({},p,{header:"Items list",headerType:"title",actionList:[{icon:"uugds-plus",
onClick:()=>m([!0,1])}]}),Uu5g05.Utils.Element.create(H,{isChecked:!0===n,onShow:()=>{s(!n)}}),Uu5g05.Utils.Element.create(l().Grid,{className:le(d)},Uu5g05.Utils.Element.create(se,{products:r,
isActive:n,isItemActive:function(e,t){a((([...n])=>{const s=n.findIndex((t=>t.id===e));return n[s].active=t,console.log(e,s),n}))},onDelete:function(e){a((([...t])=>{const n=t.findIndex((t=>t.id===e))
;return t.splice(n,1),t}))}})),Uu5g05.Utils.Element.create(R().Form.Provider,{key:c[1],onSubmit:function(e){!function(e){a((([...t])=>(console.log(t),t.push({id:i.Utils.String.generateId(),...e,
active:!0}),t)))}(e.data.value),m(!1,0)}},Uu5g05.Utils.Element.create(l().Modal,{open:1===c[1]&&c[0],onClose:()=>m(!1,0),header:"Create Shop Item",
footer:Uu5g05.Utils.Element.create("div",null,Uu5g05.Utils.Element.create(R().CancelButton,{onClick:()=>m(!1,0)}),Uu5g05.Utils.Element.create(R().SubmitButton,null))
},Uu5g05.Utils.Element.create(R().FormText,{name:"name",label:"Name"}),Uu5g05.Utils.Element.create(R().FormText,{name:"amount",label:"Amount"}),Uu5g05.Utils.Element.create(R().FormText,{name:"unit",
label:"Unit"}))),Uu5g05.Utils.Element.create(R().Form.Provider,{key:c[0],onSubmit:function(e){u((()=>o.name=e.data.value)),m(!1,0)}},Uu5g05.Utils.Element.create(l().Modal,{open:0===c[1]&&c[0],
onClose:()=>m(!1,0),header:"Edit name",footer:Uu5g05.Utils.Element.create("div",null,Uu5g05.Utils.Element.create(R().CancelButton,{onClick:()=>m(!1,0)
}),Uu5g05.Utils.Element.create(R().SubmitButton,null))},Uu5g05.Utils.Element.create(R().FormText,{initialValue:o.name,name:"name",label:"Změn jméno"}))),Uu5g05.Utils.Element.create(re,null))))}
}),ue=()=>k.Z.Css.css({});let ce=(0,i.createVisualComponent)({uu5Tag:k.Z.TAG+"Slist",propTypes:{},defaultProps:{},render(e){const{identity:t}=(0,
i.useSession)(),n=i.Utils.VisualComponent.getAttrs(e,ue());return Uu5g05.Utils.Element.create("div",n,Uu5g05.Utils.Element.create(_.Z,null),Uu5g05.Utils.Element.create(oe,{initialProducts:pe,
initialList:me[0]}),";")}});const me=[{id:i.Utils.String.generateId(),name:"Páteční nákup",archive:!1,childId:[156,142,186]}],pe=[{id:i.Utils.String.generateId(),name:"Apple",amount:5,unit:"Kg",
active:!1},{id:i.Utils.String.generateId(),name:"Car",amount:4,unit:"pieces",active:!1},{id:i.Utils.String.generateId(),name:"Knife",amount:5,unit:"pieces",active:!1},{id:i.Utils.String.generateId(),
name:"Orange",amount:10,unit:"Stock",active:!0},{id:i.Utils.String.generateId(),name:"Pumpkin",amount:4,unit:"Stock",active:!1},{id:i.Utils.String.generateId(),name:"Peas",amount:5,unit:"Kg",active:!0
}];ce=(0,c.withRoute)(ce,{authenticated:!1});const de=ce,ge=()=>E.Css.css({}),Ue=()=>E.Css.css({}),he=()=>E.Css.css({marginTop:10}),fe=()=>E.Css.css({padding:"5px",margin:5}),Ee=()=>E.Css.css({
fontStyle:"italic",marginTop:10}),ve=(e,t)=>{const n="left"===e?{marginLeft:t}:{marginRight:t};return E.Css.css(n)},Ce=(0,i.createVisualComponent)({uu5Tag:E.TAG+"SlistsTile",propTypes:{},
defaultProps:{},render(e){const{children:t}=e,[n,s]=(0,i.useState)(!1),r=(i.Utils.VisualComponent.getAttrs(e,ge()),l().UuGds.SpacingPalette.getValue(["fixed","c"]));return e.data.handlerMap.delete,
Uu5g05.Utils.Element.create(Uu5g05.Fragment,null,Uu5g05.Utils.Element.create(ee().Tile,{className:fe(),header:Uu5g05.Utils.Element.create(l().Header,{className:Ue(),title:e.data.data.name,
icon:"uugds-favorites"}),actionList:[{icon:"uugds-close",children:"Smazat",onClick:()=>s(!0)}]},Uu5g05.Utils.Element.create("div",null,Uu5g05.Utils.Element.create(l().Text,{category:"interface",
segment:"title",type:"micro"},Uu5g05.Utils.Element.create(l().Icon,{icon:"uugds-favorites",className:ve("right",r)}),e.data.data.notes)),Uu5g05.Utils.Element.create("div",{className:he()
},Uu5g05.Utils.Element.create(l().Text,null,Uu5g05.Utils.Element.create(l().Icon,{icon:"uugds-favorites"}),"Vlastník: ",e.data.data.owner_name)),Uu5g05.Utils.Element.create("div",{className:Ee()
},Uu5g05.Utils.Element.create(l().Text,{category:"interface",segment:"content",type:"medium"},"Členové: ","(",e.data.data.members.join(", "),")"))),Uu5g05.Utils.Element.create(l().Dialog,{open:n,
onCLose:()=>s(!1),header:"chcete smazat položku?",info:e.data.data.name,icon:"uugds-delete",actionList:[{children:"Smazat",colorScheme:"negative",significance:"highlighted",
onClick:()=>e.data.handlerMap.delete()},{children:"Zrušit",onClick:()=>s(!1)}]}))}});var be=n(190),ke=n.n(be);const ye=[{key:"archive",label:"Pouze Archivované",filter:(e,t)=>{if(t){
"object"==typeof e.data.archive?i.Utils.Language.getItem(e.data.archive):e.data.archive;return!0===e.data.archive}return!0},inputType:"bool"}],Se=()=>E.Css.css({display:"flex",flexDirection:"column",
height:"90%",maxWidth:"90%",marginLeft:"auto",marginRight:"auto",marginTop:"50px"}),Te=(0,i.createVisualComponent)({uu5Tag:E.TAG+"SlistsListView",propTypes:{},defaultProps:{},render(e){
const{children:t}=e,[n,s]=(i.Utils.VisualComponent.getAttrs(e,Se()),(0,i.useState)(!1)),[r,a]=(0,i.useState)([{key:"archive",value:!1}])
;return Uu5g05.Utils.Element.create(Uu5g05.Fragment,null,Uu5g05.Utils.Element.create(Q().ControllerProvider,{data:e.data,filterDefinitionList:ye,filterList:r,onFilterChange:e=>{a(e.data.filterList)}
},Uu5g05.Utils.Element.create(l().Block,{className:Se(),header:Uu5g05.Utils.Element.create(l().Header,{title:"Nákupní seznamy",subtitle:"Pro vás",icon:"uugds-favorites"}),actionList:[{
component:Uu5g05.Utils.Element.create(ke().FilterButton,{type:"bar"})},{icon:"uugdsstencil-uiaction-plus-circle-solid",children:"vytvořit",onClick:()=>s(!0)}]
},Uu5g05.Utils.Element.create(ke().FilterBar,{initialExpanded:!0,displayManagerButton:!1,displayClearButton:!1
}),Uu5g05.Utils.Element.create(ke().FilterManagerModal,null),Uu5g05.Utils.Element.create(ee().Grid,{tileMinWidth:300,tileMaxWidth:400
},Uu5g05.Utils.Element.create(Ce,null)),Uu5g05.Utils.Element.create(R().Form.Provider,{key:n,onSubmit:async t=>{await e.onCreate({id:i.Utils.String.generateId(),...t.data.value}),s(!1),
console.log("submit",t.data)}},Uu5g05.Utils.Element.create(l().Modal,{open:n,onClose:()=>{s(!1)},header:"Vytvořit seznam",footer:Uu5g05.Utils.Element.create(R().SubmitButton,null)
},Uu5g05.Utils.Element.create(R().Form.View,{gridLayout:{xs:"name, notes",s:"name notes"}},Uu5g05.Utils.Element.create(R().FormText,{name:"name",label:"Name",required:!0
}),Uu5g05.Utils.Element.create(R().FormText,{name:"notes",label:"Notes"})))))))}}),xe=(0,i.createComponent)({uu5Tag:E.TAG+"SlistsListProvider",propTypes:{},defaultProps:{},render(e){
const{children:t}=e,n=(0,i.useDataList)({handlerMap:{load:r.Z.loadSlistsList,create:r.Z.createSlist},itemHandlerMap:{delete:r.Z.deleteSlist}});let s;switch(n.state){case"pendingNoData":
s=Uu5g05.Utils.Element.create(l().Pending,{size:"max"});break;case"errorNoData":s=Uu5g05.Utils.Element.create(l().Alert,{header:"Cannot create library.",priority:"error"});break;case"error":
s=Uu5g05.Utils.Element.create(l().Alert,{header:"Data about libraries cannot be loaded.",priority:"error"});break;default:s=Uu5g05.Utils.Element.create(Te,{data:n.data,onCreate:n.handlerMap.create})}
return s}}),_e=()=>k.Z.Css.css({});let Ae=(0,i.createVisualComponent)({uu5Tag:k.Z.TAG+"Slists",propTypes:{},defaultProps:{},render(e){const{identity:t}=(0,
i.useSession)(),n=i.Utils.VisualComponent.getAttrs(e,_e());return Uu5g05.Utils.Element.create("div",n,Uu5g05.Utils.Element.create(_.Z,null),Uu5g05.Utils.Element.create(xe,null))}});Ae=(0,
c.withRoute)(Ae,{authenticated:!1})
;const Le=Ae,we=i.Utils.Component.lazy((()=>n.e(701).then(n.bind(n,701)))),Pe=i.Utils.Component.lazy((()=>n.e(327).then(n.bind(n,327)))),je=i.Utils.Component.lazy((()=>n.e(180).then(n.bind(n,180)))),Ne={
"":{redirect:"home"},home:e=>Uu5g05.Utils.Element.create(P,e),slist:e=>Uu5g05.Utils.Element.create(de,e),slists:e=>Uu5g05.Utils.Element.create(Le,e),about:e=>Uu5g05.Utils.Element.create(we,e),
"sys/uuAppWorkspace/initUve":e=>Uu5g05.Utils.Element.create(Pe,e),controlPanel:e=>Uu5g05.Utils.Element.create(je,e),"*":()=>Uu5g05.Utils.Element.create(l().Text,{category:"story",segment:"heading",
type:"h1"},"Not Found")};function Ie({children:e}){switch((0,i.useSession)().state){case"pending":return Uu5g05.Utils.Element.create(c.SpaPending,null);case"notAuthenticated":
return Uu5g05.Utils.Element.create(p.Unauthenticated,null);default:return e}}const ze=(0,i.createVisualComponent)({uu5Tag:b.Z.TAG+"Spa",propTypes:{},defaultProps:{},
render:()=>Uu5g05.Utils.Element.create(u().SpaProvider,{initialLanguageList:["en","cs"],skipAppWorkspaceProvider:!0
},Uu5g05.Utils.Element.create(Ie,null,Uu5g05.Utils.Element.create(C,null,(e=>Uu5g05.Utils.Element.create(Uu5g05.Fragment,null,"pendingNoData"===e.state&&Uu5g05.Utils.Element.create(c.SpaPending,null),"errorNoData"===e.state&&Uu5g05.Utils.Element.create(c.Error,{
error:e.errorData}),["ready","pending","error"].includes(e.state)&&Uu5g05.Utils.Element.create(m().Spa,{routeMap:Ne}))))))});if(i.Environment.appVersion="0.1.0",
!navigator.userAgent.match(/iPhone|iPad|iPod/)){let e=document.createElement("link");e.rel="manifest",e.href="assets/manifest.json",document.head.appendChild(e)}let Me;function Be(e){Me=e,
i.Utils.Dom.render(Uu5g05.Utils.Element.create(s.zj,null,Uu5g05.Utils.Element.create(ze,null)),document.getElementById(e))}},426:(e,t,n)=>{"use strict";n.d(t,{Z:()=>l});var s=n(94),i=n(823)
;const r="uu_jokes_maing01-hi",a=e=>n(394)(`./${e}.json`);a.libraryCode=r,s.Utils.Lsi.setDefaultLsi(r,{en:i});const l=a},24:(e,t,n)=>{"use strict";n.d(t,{Z:()=>a});var s=n(94),i=n(12)
;const r=i.Z.TAG+"Routes.",a={...i.Z,TAG:r,Css:s.Utils.Css.createCssModule(r.replace(/\.$/,"").toLowerCase().replace(/\./g,"-").replace(/[^a-z-]/g,""),"uu_jokes_maing01-hi/uu_jokes_maing01-hi@0.1.0")}
},280:(e,t,n)=>{
var s=n(145),i="undefined"!=typeof document,r=((s?s.uri:i&&(document.currentScript||Array.prototype.slice.call(document.getElementsByTagName("script"),-1)[0]||{}).src)||"").toString(),a="/0.0.0/"
;(r=r.split(/\//).slice(0,-1).join("/")+"/").substr(-7)===a&&(r=r.substr(0,r.length-7)+"/0.1.0/"),n.p=r,e.exports=n(187);var l=e.exports
;l&&"object"==typeof l&&("version"in l||Object.defineProperty(l,"version",{configurable:!0,value:"0.1.0"}),"name"in l||Object.defineProperty(l,"name",{configurable:!0,
value:"uu_jokes_maing01-hi".split(/[\/\\]/).pop()}),"namespace"in l||Object.defineProperty(l,"namespace",{configurable:!0,value:"UuJokes"}))},602:(e,t,n)=>{"use strict"
;var s,i=(s=n(321))&&"object"==typeof s&&"default"in s?s.default:s;function r(e){return r.warnAboutHMRDisabled&&(r.warnAboutHMRDisabled=!0,
console.error("React-Hot-Loader: misconfiguration detected, using production version in non-production environment."),console.error("React-Hot-Loader: Hot Module Replacement is not enabled.")),
i.Children.only(e.children)}r.warnAboutHMRDisabled=!1;var a=function e(){return e.shouldWrapWithAppContainer?function(e){return function(t){return i.createElement(r,null,i.createElement(e,t))}
}:function(e){return e}};a.shouldWrapWithAppContainer=!1;t.zj=r},394:(e,t,n)=>{var s={"./cs.json":[27,27],"./en.json":[823]};function i(e){if(!n.o(s,e))return Promise.resolve().then((()=>{
var t=new Error("Cannot find module '"+e+"'");throw t.code="MODULE_NOT_FOUND",t}));var t=s[e],i=t[0];return Promise.all(t.slice(1).map(n.e)).then((()=>n.t(i,19)))}i.keys=()=>Object.keys(s),i.id=394,
e.exports=i},145:t=>{"use strict";t.exports=e},321:e=>{"use strict";e.exports=m},918:e=>{"use strict";e.exports=n},94:e=>{"use strict";e.exports=t},834:e=>{"use strict";e.exports=i},389:e=>{
"use strict";e.exports=l},767:e=>{"use strict";e.exports=o},190:e=>{"use strict";e.exports=c},320:e=>{"use strict";e.exports=u},763:e=>{"use strict";e.exports=s},781:e=>{"use strict";e.exports=r},
923:e=>{"use strict";e.exports=a},119:e=>{function t(){return e.exports=t=Object.assign?Object.assign.bind():function(e){for(var t=1;t<arguments.length;t++){var n=arguments[t]
;for(var s in n)Object.prototype.hasOwnProperty.call(n,s)&&(e[s]=n[s])}return e},e.exports.__esModule=!0,e.exports.default=e.exports,t.apply(this,arguments)}e.exports=t,e.exports.__esModule=!0,
e.exports.default=e.exports},823:e=>{"use strict"
;e.exports=JSON.parse('{"appName":"Application uuShopping","About":{"header":"About application uuShopping","creatorsHeader":"Application creators","termsOfUse":"Terms of use"},"AboutContent":{"content":"<uu5string/>Demo application is a template for developing new applications.","technologiesContent":"<uu5string/>Other used technologies: <Uu5Elements.Link href=\'http://www.w3schools.com/html/default.asp\' target=\'_blank\'>Html5</Uu5Elements.Link>, <Uu5Elements.Link href=\'http://www.w3schools.com/css/default.asp\' target=\'_blank\'>CSS</Uu5Elements.Link>, <Uu5Elements.Link href=\'http://www.w3schools.com/js/default.asp\' target=\'_blank\'>JavaScript</Uu5Elements.Link>, <Uu5Elements.Link href=\'http://getbootstrap.com\' target=\'_blank\'>Bootstrap</Uu5Elements.Link>, <Uu5Elements.Link href=\'https://reactjs.org\' target=\'_blank\'>React</Uu5Elements.Link>, <Uu5Elements.Link href=\'https://www.ruby-lang.org\' target=\'_blank\'>Ruby</Uu5Elements.Link>, <Uu5Elements.Link href=\'http://puma.io\' target=\'_blank\'>Puma</Uu5Elements.Link> a <Uu5Elements.Link href=\'https://www.docker.com\' target=\'_blank\'>Docker</Uu5Elements.Link>. Application is operated in the <Uu5Elements.Link href=\'https://plus4u.net\' target=\'_blank\'>Plus4U</Uu5Elements.Link> internet service with the usage of <Uu5Elements.Link href=\'https://azure.microsoft.com\' target=\'_blank\'>Microsoft Azure</Uu5Elements.Link> cloud."},"ControlPanel":{"rightsError":"You do not have sufficient rights to display this component.","btNotConnected":"The application is not connected to a Business Territory."},"Home":{"welcome":"Welcome","intro":"<uu5string/>This template consist of prepared client and server side. Shown components demonstrate possibilities and way of using. For application developing purposes they are suitable for modifying, copying and deleting. More about uuApp Structure see documentation&nbsp; <Uu5Elements.Link href=\\"https://uuapp.plus4u.net/uu-bookkit-maing01/e884539c8511447a977c7ff070e7f2cf/book/page?code=stepByStepApp\\" target=\\"_blank\\">uuAppDevKit</Uu5Elements.Link>.","clientSide":"<uu5string/>Libraries <Uu5Elements.Link href=\\"https://uuapp.plus4u.net/uu-bookkit-maing01/05ecbf4e8bca405290b1a6d4cee8813a/book\\" target=\\"_blank\\">uu5</Uu5Elements.Link> and <Uu5Elements.Link href=\\"https://uuapp.plus4u.net/uu-bookkit-maing01/83c1406c4fc541dba975941424106318/book\\" target=\\"_blank\\">uuPlus4U5</Uu5Elements.Link> are used for developing of client side.","serverSide":"<uu5string/>It is necessary to initialize application workspace for running server side. See manual <Uu5Elements.Link href=\\"https://uuapp.plus4u.net/uu-bookkit-maing01/e884539c8511447a977c7ff070e7f2cf/book/page?code=stepByStepApp\\" target=\\"_blank\\">uuApp Template Developer Guide</Uu5Elements.Link>"},"InitAppWorkspace":{"notAuthorized":"You do not have sufficient rights to use the application.","formHeader":"Initialize uuApp","formHeaderInfo":"<uu5string/>Your uuApp is running, but requires initialization. If you need help with filling up this form, see\\n<Uu5Elements.Link target=\\"_blank\\" href=\\"#\\">Documentation</Uu5Elements.Link>.","notAuthorizedForInit":"The application is running but it was not initialized yet and you do not have sufficient rights to do so.","uuBtLocationUriLabel":"uuBusinessTerritory location","uuBtLocationUriInfo":"Uri of the uuBt location where AWSC will be created","nameLabel":"Name","initialize":"Initialize"},"Menu":{"home":"Welcome","slist":"Shopping list","slists":"Lists","about":"About Application"}}')
}},h={};function f(e){var t=h[e];if(void 0!==t)return t.exports;var n=h[e]={exports:{}};return U[e](n,n.exports,f),n.exports}return f.m=U,f.n=e=>{var t=e&&e.__esModule?()=>e.default:()=>e
;return f.d(t,{a:t}),t},d=Object.getPrototypeOf?e=>Object.getPrototypeOf(e):e=>e.__proto__,f.t=function(e,t){if(1&t&&(e=this(e)),8&t)return e;if("object"==typeof e&&e){if(4&t&&e.__esModule)return e
;if(16&t&&"function"==typeof e.then)return e}var n=Object.create(null);f.r(n);var s={};p=p||[null,d({}),d([]),d(d)]
;for(var i=2&t&&e;"object"==typeof i&&!~p.indexOf(i);i=d(i))Object.getOwnPropertyNames(i).forEach((t=>s[t]=()=>e[t]));return s.default=()=>e,f.d(n,s),n},f.d=(e,t)=>{
for(var n in t)f.o(t,n)&&!f.o(e,n)&&Object.defineProperty(e,n,{enumerable:!0,get:t[n]})},f.f={},f.e=e=>Promise.all(Object.keys(f.f).reduce(((t,n)=>(f.f[n](e,t),t)),[])),f.u=e=>"chunks/index/"+e+"-"+{
27:"ed82f5d405b531bddf3b",180:"787c76f55ea63a5b9001",327:"a5ea7da6114814e39c61",701:"a691151c06c51490ad76"}[e]+".min.js",f.o=(e,t)=>Object.prototype.hasOwnProperty.call(e,t),g={},f.l=(e,t,n,s)=>{
if(g[e])g[e].push(t);else{var i,r;if(void 0!==n)for(var a=document.getElementsByTagName("script"),l=0;l<a.length;l++){var o=a[l];if(o.getAttribute("src")==e){i=o;break}}i||(r=!0,
(i=document.createElement("script")).charset="utf-8",i.timeout=120,f.nc&&i.setAttribute("nonce",f.nc),i.src=e,0!==i.src.indexOf(window.location.origin+"/")&&(i.crossOrigin="anonymous")),g[e]=[t]
;var u=(t,n)=>{i.onerror=i.onload=null,clearTimeout(c);var s=g[e];if(delete g[e],i.parentNode&&i.parentNode.removeChild(i),s&&s.forEach((e=>e(n))),t)return t(n)},c=setTimeout(u.bind(null,void 0,{
type:"timeout",target:i}),12e4);i.onerror=u.bind(null,i.onerror),i.onload=u.bind(null,i.onload),r&&document.head.appendChild(i)}},f.r=e=>{
"undefined"!=typeof Symbol&&Symbol.toStringTag&&Object.defineProperty(e,Symbol.toStringTag,{value:"Module"}),Object.defineProperty(e,"__esModule",{value:!0})},f.p="",(()=>{var e={826:0};f.f.j=(t,n)=>{
var s=f.o(e,t)?e[t]:void 0;if(0!==s)if(s)n.push(s[2]);else{var i=new Promise(((n,i)=>s=e[t]=[n,i]));n.push(s[2]=i);var r=f.p+f.u(t),a=new Error;f.l(r,(n=>{if(f.o(e,t)&&(0!==(s=e[t])&&(e[t]=void 0),
s)){var i=n&&("load"===n.type?"missing":n.type),r=n&&n.target&&n.target.src;a.message="Loading chunk "+t+" failed.\n("+i+": "+r+")",a.name="ChunkLoadError",a.type=i,a.request=r,s[1](a)}
}),"chunk-"+t,t)}};var t=(t,n)=>{var s,i,[r,a,l]=n,o=0;if(r.some((t=>0!==e[t]))){for(s in a)f.o(a,s)&&(f.m[s]=a[s]);if(l)l(f)}for(t&&t(n);o<r.length;o++)i=r[o],f.o(e,i)&&e[i]&&e[i][0](),e[i]=0
},n=this.__webpack_jsonp_uu_jokes_maing01_hi_0_1_0_index=this.__webpack_jsonp_uu_jokes_maing01_hi_0_1_0_index||[];n.forEach(t.bind(null,0)),n.push=t.bind(null,n.push.bind(n))})(),f(280)})()));