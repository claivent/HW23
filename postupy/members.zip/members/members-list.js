"use strict";
const { UuObjectDao } = require("uu_appg01_server").ObjectStore;



class SlistMongo extends UuObjectDao {

  async createSchema() {
    await super.createIndex({ awid: 1, _id: 1 }, { unique: true });
  }
  async initCreate(uuObject) {
    return super.insertMany([uuObject]);
  }

  async create(uuObject) {
    return await super.insertOne(uuObject);
  }

  async list(awid, sortBy, order, pageInfo) {


    const sort = {
      [sortBy]: order === "asc" ? 1 : -1,
    };
    return ( await super.find({ awid }, { sort, skip: pageInfo.pageIndex * pageInfo.pageSize, limit: pageInfo.pageSize }));

  }

  async delete(awid, id) {
    await super.deleteOne({ awid, id });
  }
}

module.exports = SlistMongo;
