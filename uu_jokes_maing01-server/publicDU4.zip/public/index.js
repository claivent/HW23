/*!
 * UAF COMMERCIAL LICENSE
 * ----------------------
 * 1. PREAMBLE and Definitions
 *   1.1 These UAF Commercial License Terms ("UAF CLT") govern licensing of the Unicorn Application Framework (UAF).
 *     The Customer and Unicorn concluded an agreement for the provision of Solution that is using UAF or its parts
 *     (the "Agreement").
 *   1.2 The provisions of these UAF CLT shall govern the relationship between the Customer and Unicorn regarding
 *     the UAF License granted under the Agreement. For the avoidance of doubt, in case of any conflict between these
 *     UAF CLT and the Agreement, the provisions of the Agreement always prevail.
 *   1.3 The "UAF Components", and each of them individually as "UAF Component", shall mean the components of the Unicorn
 *     Application Framework, which are listed and described in the Attachment I to these UAF CLT.
 *   1.4 "UAF" shall mean the Unicorn Application Framework the scope of which is described in Attachment I, including all
 *     associated documentation and preparatory design materials, in particular blueprints, models, user manuals,
 *     training materials, comprehensive instructions and guidelines for drafting, production, operation and maintenance of
 *     software solutions, reference architecture, ready-made components and tools, use cases and tutorials.
 *   1.5 The "Knowledge Base" shall mean the online materials, internet fora and other resources made available by Unicorn
 *     online with regard to the UAF, intended for the broad customer and developer community.
 *   1.6 The "License" shall mean the binding terms and conditions for use of the UAF by the Customer. The License is
 *     described in Clause 2 and may be further specified or modified by the Agreement.
 *   1.7 The "Solution" shall mean any product or service developed under the Agreement using the UAF or any of
 *     UAF Components or its other parts, further specified in the Agreement.
 * 2. LICENSE GRANT
 *   2.1 The Customer shall be hereby granted a non-exclusive and non-transferable worldwide license to use the UAF for
 *     the purpose of the Solution described in the Agreement. For this purpose, the Customer shall be entitled to modify
 *     the UAF and create derivative works based on the UAF.
 *   2.2 The Customer is entitled to grant third parties a sub-license allowing them to use the UAF or any derivative works
 *     based on the UAF under commercial terms of its choice, provided that:
 *     2.2.1 use of the UAF and any derivative works based on the UAF by third parties is limited to testing, handover and
 *       operation of the Solution or its use as a service,
 *     2.2.2 third parties are not entitled to use the UAF or any derivative works based on the UAF independently of
 *       the Solution,
 *     2.2.3 third parties are not provided access to source code of the UAF unless such right is granted by the Agreement
 *       or if they conclude a commercial license agreement with Unicorn.
 *   2.3 The Solution or its parts based on the UAF shall bear a prominent copyright notice "Based on Unicorn Application
 *     Framework Copyright (c) Unicorn" integrated
 *     2.3.1 in the graphical user interface of the Solution or its relevant part or
 *     2.3.2 in accompanying file if the Solution or its relevant part do not have graphical user interface or
 *     2.3.3 in Solution's documentation.
 *   2.4 The License shall be valid for the whole duration of copyright to the UAF, unless other duration of the License is
 *     specified in the Agreement.
 *   2.5 The Customer is entitled to access the Knowledge Base only if expressly agreed in the Agreement.
 *   2.6 The Unicorn retains all rights to the UAF not covered by the provisions of this Clause 2. Unless explicitly
 *     permitted by applicable law, the Customer may not use the UAF in any other way than provided by the provisions of
 *     this Clause 2 and may not allow such use on its behalf by any of its employees or agents.
 *   2.7 The price for the License is included in the price stipulated in the Agreement.
 * 3. MODIFICATIONS
 *   3.1 The Customer explicitly acknowledges that the UAF is under continuous development and any UAF Component or other
 *     part of the UAF may be modified, replaced or removed by the Unicorn from the UAF in any of its future versions.
 *   3.2 This License covers also any new version of UAF if some parts of the UAF are modified or replaced.
 *   3.3 If any part of the UAF is removed by Unicorn in any of its future versions, the License for such version of
 *     the UAF is reduced appropriately and covers only the remaining parts of UAF. Sub-licenses previously granted to
 *     third parties in accordance with Clause 2.2 remain unaffected.
 * 4. THIRD PARTY LICENSE TERMS
 *   4.1 UAF is using third party software tools (the "Third Party Software") that is an integral part of the UAF. Some of
 *     these tools are free software or open-source SW.
 *   4.2 The list of Third Party Software used in the UAF including its license terms and authors is provided as part of
 *     Attachment I to these UAF CLT.
 *   4.3 For the use of the above mentioned Third Party Software, the Customer acknowledges its license terms referred to
 *     in Attachment I to these UAF CLT.
 * 5. NO TRADEMARK OR PATENT LICENSE
 *   5.1 These UAF CLT cover only copyright use of the UAF. If not expressly agreed otherwise, the Customer shall not be
 *     granted any trademark and/or patent license here under and nothing in these UAF CLT shall be interpreted in a way it
 *     does so.
 * 6. LIMITED WARRANTY
 *   6.1 IF NOT STIPULATED OTHER WISE OR REQUIRED BY APPLICABLE LAW, THE UAF IS PROVIDED ON "AS IS" BASIS,
 *     WITH NO WARRANTY OF, INCLUDING WITHOUT LIMITATION, MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE ENTIRE
 *     RISK AS TO THE QUALITY AND PERFORMANCE OF THE UAF IS CARRIED SOLELY BY THE CUSTOMER, UNLESS OTHERWISE AGREED BETWEEN
 *     THE UNICORN AND THE CUSTOMER IN THE AGREEMENT.
 * 7. LIMITATION OF LIABILITY
 *   7.1 TO THE EXTENT PERMITTED BY APPLICABLE LAW, THE UNICORN WILL NOT BE HELD LIABLE FOR ANY DAMAGES CAUSED BY
 *     THE DISTRIBUTION OR USE OF THE UAF. THIS ALSO INCLUDES ANY CONSEQUENTIAL AND/OR INCIDENTAL DAMAGES, MONETARY OR NOT,
 *     THAT ARE CONNECTED WITH THE DISTRIBUTION OR USE OF THE UAF, UNLESS OTHERWISE AGREED BETWEEN THE UNICORN AND
 *     THE CUSTOMER IN THE AGREEMENT.
 * 8. THIRD PARTY CLAIMS
 *   8.1 The Unicorn will defend or settle, at its option and expense, any action brought against the Customer in a member
 *     state of the European Union which concerns an allegation that the UAF provided infringes a patent or copyright or
 *     misappropriates a trade secret in such jurisdiction. The Unicorn shall pay costs and damages finally awarded against
 *     the Customer that are attributable to such action. The Customer declares to understand and agrees that following
 *     conditions must be fulfilled in order to make Unicorn's obligations under this Clause 8 effective and enforceable:
 *     The Customer must (a) notify Unicorn promptly in writing of the action or any reasonable threat of it,
 *     (b) provide the Unicorn with all reasonable information and assistance it will request to settle or defend the action, and
 *     (c) grant the Unicorn sole authority and control of the defense or settlement of the action.
 *   8.2 If a claim is made under Clause 8.1 the Unicorn may, at its sole option and expense:
 *     (a) replace or modify the UAF so that it becomes non-infringing,
 *     (b) procure for the Customer the right to continue using the UAF unmodified.
 *   8.3 The Unicorn shall not be held liable to the Customer if the action is based on:
 *     (a) the combination of UAF with any product not provided by Unicorn,
 *     (b) the modification of the UAF other than by Unicorn,
 *     (c) the use of other than a current unaltered release of the UAF,
 *     (d) a product that the Customer makes, uses, or sells,
 *     (e) infringement by the Customer that is deemed willful. In the case under (e) the Customer shall reimburse
 *     the Unicorn for its reasonable attorney fees and other costs related to the action.
 *   8.4 THIS CLAUSE IS SUBJECT TO CLAUSE 7 AND STATES UNICORN'S ENTIRE LIABILITY, CUSTOMER'S SOLE AND EXCLUSIVE REMEDY,
 *     FOR DEFENSE, SETTLEMENT AND DAMAGES, WITH RESPECT TO ANY ALLEGED PATENT OR COPYRIGHT INFRINGEMENT OR TRADE SECRET
 *     MISAPPROPRIATION BY ANY ITEM PROVIDED UNDER THESE TERMS, UNLESS OTHERWISE AGREEMENT BETWEEN UNICORN AND THE CUSTOMER
 *     IN THE AGREEMENT.
 * 9. GENERAL PROVISIONS
 *   9.1 By entering into the Agreement, the Customer signifies its assent to and acceptance of these UAF CLT.
 *   9.2 The License is effective from the moment of execution of the Agreement, if the Agreement does not specify later
 *     date. Where the provisions of the Agreement regarding the License and provisions of these UAF CLT differ, provisions
 *     of the Agreement shall prevail.
 *   9.3 If any provision of the Agreement regarding the License or these UAF CLT is held by a court of competent
 *     jurisdiction to be void, invalid, unenforceable or illegal, such provision shall be severed from the Agreement or
 *     these UAF CLT and the remaining provisions will remain in full force and effect.
 *   9.4 The provisions of Clauses 7 and 8 shall survive any expiration or termination of the Agreement.
 *   9.5 All rights and obligations between the Unicorn and the Customer arising on the basis of these UAF CLT or
 *     in connection with them are governed by the laws of the Czech Republic with the exclusion of both the rules on
 *     the conflict of laws and the United Nations Convention on Contracts for the International Sale of Goods (CISG).
 *   9.6 The resolution of all disputes arising from or connected here to shall be under sole jurisdiction of the courts of
 *     the Czech Republic.
 */
!function(e,t){
"object"==typeof exports&&"object"==typeof module?module.exports=t(require("module"),require("uu5g05"),require("uu5g04"),require("uu_plus4u5g02"),require("uu5g05-elements"),require("uu_plus4u5g02-app"),require("uu_plus4u5g02-elements"),require("uu5g05-forms"),require("uu5tilesg02"),require("uu5tilesg02-elements"),require("uu5tilesg02-controls")):"function"==typeof define&&define.amd?define("index",["module","uu5g05","uu5g04","uu_plus4u5g02","uu5g05-elements","uu_plus4u5g02-app","uu_plus4u5g02-elements","uu5g05-forms","uu5tilesg02","uu5tilesg02-elements","uu5tilesg02-controls"],t):"object"==typeof exports?exports.index=t(require("module"),require("uu5g05"),require("uu5g04"),require("uu_plus4u5g02"),require("uu5g05-elements"),require("uu_plus4u5g02-app"),require("uu_plus4u5g02-elements"),require("uu5g05-forms"),require("uu5tilesg02"),require("uu5tilesg02-elements"),require("uu5tilesg02-controls")):e.index=t(e[void 0],e.uu5g05,e.uu5g04,e.uu_plus4u5g02,e["uu5g05-elements"],e["uu_plus4u5g02-app"],e["uu_plus4u5g02-elements"],e["uu5g05-forms"],e.uu5tilesg02,e["uu5tilesg02-elements"],e["uu5tilesg02-controls"])
}(this,((e,t,n,s,a,i,l,r,o,u,c)=>(()=>{var d,m,p,g,U={899:(e,t,n)=>{"use strict";n.d(t,{Z:()=>r});var s=n(94),a=n(763),i=n.n(a);const l={
call:async(e,t,n,s)=>(await i().Utils.AppClient[e](t,n,s)).data,deleteSlist(e){console.log("Calls delete",e);const t=l.getCommandUri("slist/delete");return l.call("post",t,e)},createSlist(e){
console.log("Calls create",e);const t=l.getCommandUri("slist/create"),n=l.call("post",t,e);return console.log("Calls create RESULT",e),n},loadSlistsList(e){const t=l.getCommandUri("slist/list")
;return l.call("get",t,e)},updateSlist(e){console.log("Calls update",e);const t=l.getCommandUri("slist/update");return l.call("post",t,e)},loadMokSys(e){const t=l.getCommandUri("slist/mokSys")
;return l.call("get",t),e},loadIdentityProfiles(){const e=l.getCommandUri("sys/uuAppWorkspace/initUve");return l.call("get",e)},initWorkspace(e){const t=l.getCommandUri("sys/uuAppWorkspace/init")
;return l.call("post",t,e)},getWorkspace(){const e=l.getCommandUri("sys/uuAppWorkspace/get");return l.call("get",e)},initAndGetWorkspace:async e=>(await l.initWorkspace(e),await l.getWorkspace()),
Slists:{load(e){const t=l.getCommandUri("sys/uuAppWorkspace/load");return l.call("get",t,e)}},getCommandUri:(e,t=s.Environment.appBaseUri)=>(t.endsWith("/")?t:t+"/")+(e.startsWith("/")?e.slice(1):e)
},r=l},12:(e,t,n)=>{"use strict";n.d(t,{Z:()=>i});var s=n(94);const a="UuJokes.",i={TAG:a,
Css:s.Utils.Css.createCssModule(a.replace(/\.$/,"").toLowerCase().replace(/\./g,"-").replace(/[^a-z-]/g,""),"uu_jokes_maing01-hi/uu_jokes_maing01-hi@0.1.0")}},640:(e,t,n)=>{"use strict";n.d(t,{Z:()=>l
});var s=n(94),a=n(12);const i=a.Z.TAG+"Core.",l={...a.Z,TAG:i,
Css:s.Utils.Css.createCssModule(i.replace(/\.$/,"").toLowerCase().replace(/\./g,"-").replace(/[^a-z-]/g,""),"uu_jokes_maing01-hi/uu_jokes_maing01-hi@0.1.0")}},722:(e,t,n)=>{"use strict";n.d(t,{
ZP:()=>l});var s=n(94);const[a,i]=s.Utils.Context.create(),l=a},873:(e,t,n)=>{"use strict";n.d(t,{Z:()=>d});var s=n(119),a=n.n(s),i=n(94),l=n(781),r=n.n(l),o=n(640),u=n(426),c=(n(763),n(722))
;const d=(0,i.createVisualComponent)({uu5Tag:o.Z.TAG+"RouteBar",propTypes:{},defaultProps:{},render(e){const[,t]=(0,i.useRoute)(),n=(0,i.useContext)(c.ZP),s=[{
children:Uu5g05.Utils.Element.create(i.Lsi,{import:u.Z,path:["Menu","home"]}),onClick:()=>t("home")},{children:Uu5g05.Utils.Element.create(i.Lsi,{import:u.Z,path:["Menu","slist"]}),
onClick:()=>t("slist")},{children:Uu5g05.Utils.Element.create(i.Lsi,{import:u.Z,path:["Menu","slists"]}),onClick:()=>t("slists")},{children:Uu5g05.Utils.Element.create(i.Lsi,{import:u.Z,
path:["Menu","about"]}),onClick:()=>t("about"),collapsed:!0}];return Uu5g05.Utils.Element.create(r().RouteBar,a()({appActionList:s},e),Uu5g05.Utils.Element.create(r().RouteHeader,{
title:n.data.data.name}))}})},988:(e,t,n)=>{"use strict";n.r(t),n.d(t,{render:()=>Be});var s=n(332),a=n(94),i=(n(918),
n(899)),l=n(834),r=n.n(l),o=n(763),u=n.n(o),c=n(781),d=n.n(c),m=n(923),p=n.n(m),g=n(873),U=n(640),h=n(24),f=n(12);const E=f.Z.TAG+"Bricks.",v={...f.Z,TAG:E,
Css:a.Utils.Css.createCssModule(E.replace(/\.$/,"").toLowerCase().replace(/\./g,"-").replace(/[^a-z-]/g,""),"uu_jokes_maing01-hi/uu_jokes_maing01-hi@0.1.0")},C=({screenSize:e})=>v.Css.css({
display:"flex",maxWidth:624,padding:"24px 0",margin:"0 auto",flexWrap:"wrap",..."xs"===e?{justifyContent:"center",textAlign:"center"}:null}),k=()=>v.Css.css({padding:"0 24px"
}),y=({screenSize:e})=>v.Css.css({flex:1,minWidth:"xs"===e?"100%":0}),b=(0,a.createVisualComponent)({uu5Tag:v.TAG+"WelcomeRow",propTypes:{left:a.PropTypes.node},defaultProps:{left:void 0},render(e){
const{left:t,children:n}=e,[s]=(0,a.useScreenSize)(),i=a.Utils.VisualComponent.getAttrs(e,C({screenSize:s}));return Uu5g05.Utils.Element.create("div",i,Uu5g05.Utils.Element.create("div",{className:k({
screenSize:s})},t),Uu5g05.Utils.Element.create("div",{className:y({screenSize:s})},n))}});var S=n(426);const T=()=>h.Z.Css.css({fontSize:48,lineHeight:"1em"});let A=(0,a.createVisualComponent)({
uu5Tag:h.Z.TAG+"Home",propTypes:{},defaultProps:{},render(e){const{identity:t}=(0,a.useSession)(),n=a.Utils.VisualComponent.getAttrs(e)
;return Uu5g05.Utils.Element.create("div",n,Uu5g05.Utils.Element.create(g.Z,null),Uu5g05.Utils.Element.create(b,{left:Uu5g05.Utils.Element.create(p().PersonPhoto,{size:"xl",borderRadius:"none"})
},Uu5g05.Utils.Element.create(r().Text,{category:"story",segment:"heading",type:"h2"},Uu5g05.Utils.Element.create(a.Lsi,{import:S.Z,path:["Home","welcome"]})),t&&Uu5g05.Utils.Element.create(r().Text,{
category:"story",segment:"heading",type:"h2"},t.name)),Uu5g05.Utils.Element.create(b,{left:Uu5g05.Utils.Element.create(r().Icon,{icon:"mdi-human-greeting",className:T()})
},Uu5g05.Utils.Element.create(r().Text,{category:"story",segment:"body",type:"common"},Uu5g05.Utils.Element.create(a.Lsi,{import:S.Z,path:["Home","intro"]}))),Uu5g05.Utils.Element.create(b,{
left:Uu5g05.Utils.Element.create(r().Icon,{icon:"mdi-monitor",className:T()})},Uu5g05.Utils.Element.create(r().Text,{category:"story",segment:"body",type:"common"},Uu5g05.Utils.Element.create(a.Lsi,{
import:S.Z,path:["Home","clientSide"]}))),Uu5g05.Utils.Element.create(b,{left:Uu5g05.Utils.Element.create(r().Icon,{icon:"mdi-server",className:T()})},Uu5g05.Utils.Element.create(r().Text,{
category:"story",segment:"body",type:"common"},Uu5g05.Utils.Element.create(a.Lsi,{import:S.Z,path:["Home","serverSide"]}))))}});A=(0,c.withRoute)(A,{authenticated:!0});const L=A,x=v.TAG+"Help.",_={
...v,TAG:x,Css:a.Utils.Css.createCssModule(x.replace(/\.$/,"").toLowerCase().replace(/\./g,"-").replace(/[^a-z-]/g,""),"uu_jokes_maing01-hi/uu_jokes_maing01-hi@0.1.0")
},w=()=>_.Css.css({}),P=()=>_.Css.css({fontSize:30,lineHeight:"1em",display:"block"}),I=()=>_.Css.css({marginLeft:"10px"}),j=()=>_.Css.css({marginLeft:"40px"}),N=()=>_.Css.css({marginLeft:"40px"
}),M=(0,a.createVisualComponent)({uu5Tag:_.TAG+"Tree",nestingLevel:["areaCollection","area"],propTypes:{},defaultProps:{},render(e){
const{children:t}=e,n=a.Utils.VisualComponent.getAttrs(e,w()),s=a.Utils.NestingLevel.getNestingLevel(e,M)
;return s?Uu5g05.Utils.Element.create("div",n,Uu5g05.Utils.Element.create("div",null,"Visual Component ",M.uu5Tag),Uu5g05.Utils.Element.create(a.Content,{nestingLevel:s
},t,Uu5g05.Utils.Element.create("ul",{className:P()+" "+I()}," MainBox",Uu5g05.Utils.Element.create("ul",{className:j()
},"TopBar",Uu5g05.Utils.Element.create("li",null,"SearchBar")),Uu5g05.Utils.Element.create("ul",{className:j()
},"SListBar (list of lists)",Uu5g05.Utils.Element.create("li",null,"CategoryRow"),Uu5g05.Utils.Element.create("li",null,"Item (list)"),Uu5g05.Utils.Element.create("li",null,"SBtnBox"),Uu5g05.Utils.Element.create("ul",{
className:N()
},"SListBar   (list of Items)",Uu5g05.Utils.Element.create("li",null,"CategoryRow"),Uu5g05.Utils.Element.create("li",null,"Item (list)"),Uu5g05.Utils.Element.create("li",null,"SBtnBox"))),Uu5g05.Utils.Element.create("ul",{
className:j()},"Footbar",Uu5g05.Utils.Element.create("li",null,"RouteBar"))))):null}});var Z=n(119),D=n.n(Z);const z=v.TAG+"Slist.",B={...v,TAG:z,
Css:a.Utils.Css.createCssModule(z.replace(/\.$/,"").toLowerCase().replace(/\./g,"-").replace(/[^a-z-]/g,""),"uu_jokes_maing01-hi/uu_jokes_maing01-hi@0.1.0")};var V=n(389),O=n.n(V)
;const G=()=>B.Css.css({}),R=(0,a.createVisualComponent)({uu5Tag:B.TAG+"SearchBar",propTypes:{},defaultProps:{},render(e){const{children:t}=e;a.Utils.VisualComponent.getAttrs(e,G())
;return Uu5g05.Utils.Element.create(O().Form,null,Uu5g05.Utils.Element.create(O().Checkbox,{label:"Show only active items",value:e.isChecked,onChange:e.onShow}))}}),F=()=>B.Css.css({}),W=e=>{let t
;switch(e){case"xs":case"s":t="100%";break;case"m":case"l":t=640;break;default:t=1280}return B.Css.css({maxWidth:t,margin:"0px auto",paddingLeft:8,paddingRight:8})},q=(0,a.createVisualComponent)({
uu5Tag:B.TAG+"SItem",propTypes:{},defaultProps:{},render(e){const{children:t}=e,[n,s]=(0,a.useState)(e.product.name),[i,l]=(0,a.useState)(e.product.amount),[o,u]=(0,
a.useState)(e.product.unit),c=e.product.active;const d=a.Utils.VisualComponent.getAttrs(e,F());return console.log(e.product),Uu5g05.Utils.Element.create(r().ListItem,D()({},d,{icon:"uugds-dnd",
actionList:[{icon:"uugds-delete",primary:!0,onClick:e.onDelete}]}),Uu5g05.Utils.Element.create(O().Text.Input,{value:n,onChange:e=>s(e.data.value),placeholder:"Vlož jméno",significance:"distinct",
className:W(a.useScreenSize)}),Uu5g05.Utils.Element.create(O().Text.Input,{value:i,onChange:e=>l(e.data.value),placeholder:"Množství",significance:"distinct",className:W(a.useScreenSize)
}),Uu5g05.Utils.Element.create(O().Text.Input,{value:o,onChange:e=>u(e.data.value),placeholder:"Jednotka množství",significance:"distinct",className:W(a.useScreenSize)
}),Uu5g05.Utils.Element.create(O().Checkbox,{value:c,box:c,name:"active",label:"nakoupeno",onChange:t=>{!function(t,n){e.isItemActive(t,n)}(e.product.id,t.data.value)},className:W(a.useScreenSize)}))}
});var H=n(767),$=n.n(H),J=n(320),Y=n.n(J);const K=()=>B.Css.css({}),Q=()=>B.Css.css({margin:"24px 0px",border:"2px solid black"}),X=(0,a.createVisualComponent)({uu5Tag:B.TAG+"SItems",propTypes:{},
defaultProps:{},render(e){const{children:t}=e,n=e.products;a.Utils.VisualComponent.getAttrs(e,K());return console.log("Products",e.products,e.isActive),
Uu5g05.Utils.Element.create(r().Grid.Item,null,n.filter((t=>!e.isActive||!t.active)).map((t=>Uu5g05.Utils.Element.create(q,{className:Q(),key:t.id,product:t,onDelete:()=>{return n=t.id,
void e.onDelete(n);var n},isItemActive:e.isItemActive}))))}}),ee=()=>B.Css.css({}),te=(0,a.createVisualComponent)({uu5Tag:B.TAG+"Footbar",propTypes:{},defaultProps:{},render(e){
const{children:t}=e,n=a.Utils.VisualComponent.getAttrs(e,ee());return Uu5g05.Utils.Element.create("div",n)}}),ne=v.TAG+"Slists.",se={...v,TAG:ne,
Css:a.Utils.Css.createCssModule(ne.replace(/\.$/,"").toLowerCase().replace(/\./g,"-").replace(/[^a-z-]/g,""),"uu_jokes_maing01-hi/uu_jokes_maing01-hi@0.1.0")
},ae=()=>se.Css.css({}),ie=()=>se.Css.css({}),le=()=>se.Css.css({marginTop:10}),re=()=>se.Css.css({padding:"5px",margin:5}),oe=()=>se.Css.css({fontStyle:"italic",marginTop:10}),ue=(e,t)=>{
const n="left"===e?{marginLeft:t}:{marginRight:t};return se.Css.css(n)},ce=e=>{const t=!1===e?{display:"none"}:{display:"block"};return se.Css.css(t)},de=(0,a.createVisualComponent)({
uu5Tag:se.TAG+"SlistsTile",propTypes:{},defaultProps:{},render(e){console.log("SLISTS-TILE",e),console.log("archive",e.data.data.isArchived);const{children:t}=e,[n,s]=(0,a.useState)(!1),[,i]=(0,
a.useRoute)(),l=(a.Utils.VisualComponent.getAttrs(e,ae()),r().UuGds.SpacingPalette.getValue(["fixed","c"]));return e.data.handlerMap.delete,
Uu5g05.Utils.Element.create(Uu5g05.Fragment,null,Uu5g05.Utils.Element.create(Y().Tile,{className:re(),header:Uu5g05.Utils.Element.create(r().Header,{className:ie(),title:e.data.data.name,
icon:"uugds-favorites"}),actionList:[{icon:"uugds-pencil",children:Uu5g05.Utils.Element.create(a.Lsi,{import:S.Z,path:["Menu","slist"]}),onClick:()=>i("slist",{listName:e.data.data.id})},{
icon:"uugds-close",children:"Smazat",onClick:()=>s(!0)},{icon:"uugdsstencil-uiaction-archive",children:"Archivovat",onClick:async()=>{var t;await e.onUpdates((t={...e.data},
console.log("handleIsArchived",t),{id:t.data.id,isArchived:!e.data.data.isArchived}))}}]},Uu5g05.Utils.Element.create("div",null,Uu5g05.Utils.Element.create(r().Text,{category:"interface",
segment:"title",type:"micro"},Uu5g05.Utils.Element.create(r().Icon,{icon:"uugds-favorites",className:ue("right",l)}),e.data.data.notes)),Uu5g05.Utils.Element.create("div",{className:le()
},Uu5g05.Utils.Element.create(r().Text,null,Uu5g05.Utils.Element.create(r().Icon,{icon:"uugds-favorites"}),"Vlastník: ",e.data.data.owner_name)),Uu5g05.Utils.Element.create("div",{className:oe()
},Uu5g05.Utils.Element.create(r().Text,{category:"interface",segment:"content",type:"medium"
},"Členové: ","(",e.data.data.members.join(", "),")")),Uu5g05.Utils.Element.create("div",null,Uu5g05.Utils.Element.create(r().Text,{className:ce(e.data.data.isArchived)
},"Archived ",e.data.data.isArchived))),Uu5g05.Utils.Element.create(r().Dialog,{open:n,onCLose:()=>s(!1),header:"chcete smazat položku?",info:e.data.data.name,icon:"uugds-delete",actionList:[{
children:"Smazat",colorScheme:"negative",significance:"highlighted",onClick:async()=>{var t;await e.onDelete((t={...e.data},console.log("handleDeleteTile",t),s(!1),{id:t.data.id}))}},{
children:"Zrušit",onClick:()=>s(!1)}]}))}});var me=n(190),pe=n.n(me);const ge=[{key:"archive",label:"Pouze Archivované",filter:(e,t)=>{if(console.log("Archiveitem",e,"value",t),t){
let t="object"==typeof e.data.isArchived?a.Utils.Language.getItem(e.data.isArchived):e.data.isArchived;return console.log("archiveItemValue",t),!0===e.data.isArchived}return!0},inputType:"bool"
}],Ue=()=>se.Css.css({display:"flex",flexDirection:"column",height:"90%",maxWidth:"90%",marginLeft:"auto",marginRight:"auto",marginTop:"50px"}),he=(0,a.createVisualComponent)({
uu5Tag:se.TAG+"SlistsListView",propTypes:{},defaultProps:{},render(e){console.log("SLISTS-VIEW",e);const{children:t}=e,[n,s]=(a.Utils.VisualComponent.getAttrs(e,Ue()),(0,a.useState)(!1)),[i,l]=(0,
a.useState)([{key:"archive",value:!1}]);return Uu5g05.Utils.Element.create(Uu5g05.Fragment,null,Uu5g05.Utils.Element.create($().ControllerProvider,{data:e.data,filterDefinitionList:ge,filterList:i,
onFilterChange:e=>{l(e.data.filterList)}},Uu5g05.Utils.Element.create(r().Block,{className:Ue(),header:Uu5g05.Utils.Element.create(r().Header,{title:"Nákupní seznamy",subtitle:"Pro vás",
icon:"uugds-favorites"}),actionList:[{component:Uu5g05.Utils.Element.create(pe().FilterButton,{type:"bar"})},{icon:"uugdsstencil-uiaction-plus-circle-solid",children:"vytvořit",onClick:()=>s(!0)}]
},Uu5g05.Utils.Element.create(pe().FilterBar,{initialExpanded:!0,displayManagerButton:!1,displayClearButton:!1
}),Uu5g05.Utils.Element.create(pe().FilterManagerModal,null),Uu5g05.Utils.Element.create(Y().Grid,{tileMinWidth:300,tileMaxWidth:400},Uu5g05.Utils.Element.create(de,{onDelete:e.onDelete,
onUpdates:e.onUpdates})),Uu5g05.Utils.Element.create(O().Form.Provider,{key:n,onSubmit:async t=>{var n;await e.onCreate((n={...t.data.value},console.log("submit",n),{name:n.name,notes:n.notes})),
s(!1),console.log("submit",t.data)}},Uu5g05.Utils.Element.create(r().Modal,{open:n,onClose:()=>{s(!1)},header:"Vytvořit seznam",footer:Uu5g05.Utils.Element.create(O().SubmitButton,null)
},Uu5g05.Utils.Element.create(O().Form.View,{gridLayout:{xs:"name, notes",s:"name notes"}},Uu5g05.Utils.Element.create(O().FormText,{name:"name",label:"Name",required:!0,minLength:3,maxLength:100
}),Uu5g05.Utils.Element.create(O().FormText,{name:"notes",label:"Notes",minLength:3,maxLength:4e3})))))))}}),fe=(0,a.createComponent)({uu5Tag:se.TAG+"SlistsListProvider",propTypes:{},defaultProps:{},
render(e){console.log("SLISTS-PROVIDER",e);const{children:t}=e,[n,s]=(0,a.useState)(!1),[l,o]=(0,a.useState)(!1),[u,c]=(0,a.useState)("");console.log("100deleted",l),console.log("110datalistState",u)
;const d=(0,a.useDataList)({handlerMap:{load:function(){return console.log("340datalist"),i.Z.loadSlistsList()},create:function(e){return console.log("340datalist"),i.Z.createSlist(e)}},
itemHandlerMap:{delete:m,isArchive:p}});async function m(e){console.log("handleDataListDelete",e);let t=await i.Z.deleteSlist(e);return console.log(t),d.handlerMap.load(),t}async function p(e){
console.log("handleSsArchive",e);let t=await i.Z.updateSlist(e);return console.log(t),d.handlerMap.load(),t}let g;switch(console.log("datalist",d),d.state){case"pendingNoData":
g=Uu5g05.Utils.Element.create(r().Pending,{size:"max"});break;case"errorNoData":g=Uu5g05.Utils.Element.create(r().Alert,{header:"Cannot create library.",priority:"error"});break;case"error":
g=Uu5g05.Utils.Element.create(r().Alert,{header:"Data about libraries cannot be loaded.",priority:"error"});break;default:g=Uu5g05.Utils.Element.create(he,{data:d.data,setData:l,
onCreate:d.handlerMap.create,onDelete:m,onUpdates:p}),console.log("400READYFUNCTION",d.data)}return g}}),Ee=()=>B.Css.css({BackgroundColor:"grey"}),ve=e=>{let t;switch(e){case"xs":case"s":t="100%"
;break;case"m":case"l":t=640;break;default:t=1280}return B.Css.css({maxWidth:t,margin:"0px auto",paddingLeft:8,paddingRight:8})},Ce=(0,a.createVisualComponent)({uu5Tag:B.TAG+"MainBox",propTypes:{},
defaultProps:{},render(e){const{children:t}=e,[n,s]=(0,a.useState)(!1),[i,l]=(0,a.useState)(),[o,u]=(0,a.useState)(),[c,d]=(0,a.useState)([!1,0]);if(!o){const[t,n]=(0,
a.useRoute)(),{listName:s}=t.params;console.log("listName",s),console.log("props",e);let i=0,r=0;e.data.map((e=>{s===e.data.id&&(r=i),i++})),r=e.data[r].data,console.log("oneList",r),u(r),
l(r.shoppingItems)}const m=a.Utils.VisualComponent.getAttrs(e,Ee()),[p]=(0,a.useScreenSize)();return Uu5g05.Utils.Element.create("div",{className:ve(p)},Uu5g05.Utils.Element.create(r().Block,{
header:"list.name",headerType:"title",actionList:[{icon:"uugds-pencil",onClick:()=>d([!0,0])}]},Uu5g05.Utils.Element.create(r().Block,D()({},m,{header:"Items list",headerType:"title",actionList:[{
icon:"uugds-plus",onClick:()=>d([!0,1])}]}),Uu5g05.Utils.Element.create(R,{isChecked:!0===n,onShow:()=>{s(!n)}}),Uu5g05.Utils.Element.create(r().Grid,{className:ve(p)},Uu5g05.Utils.Element.create(X,{
products:i,isActive:n,isItemActive:function(e,t){l((([...n])=>{const s=n.findIndex((t=>t.id===e));return n[s].active=t,console.log(e,s),n}))},onDelete:function(e){l((([...t])=>{
const n=t.findIndex((t=>t.id===e));return t.splice(n,1),t}))}})),Uu5g05.Utils.Element.create(O().Form.Provider,{key:c[1],onSubmit:function(e){!function(e){l((([...t])=>(console.log(t),t.push({
id:a.Utils.String.generateId(),...e,active:!0}),t)))}(e.data.value),d(!1,0)}},Uu5g05.Utils.Element.create(r().Modal,{open:1===c[1]&&c[0],onClose:()=>d(!1,0),header:"Create Shop Item",
footer:Uu5g05.Utils.Element.create("div",null,Uu5g05.Utils.Element.create(O().CancelButton,{onClick:()=>d(!1,0)}),Uu5g05.Utils.Element.create(O().SubmitButton,null))
},Uu5g05.Utils.Element.create(O().FormText,{name:"name",label:"Name"}),Uu5g05.Utils.Element.create(O().FormText,{name:"amount",label:"Amount"}),Uu5g05.Utils.Element.create(O().FormText,{name:"unit",
label:"Unit"}))),Uu5g05.Utils.Element.create(O().Form.Provider,{key:c[0],onSubmit:function(e){u((()=>o.name=e.data.value)),d(!1,0)}},Uu5g05.Utils.Element.create(r().Modal,{open:0===c[1]&&c[0],
onClose:()=>d(!1,0),header:"Edit name",footer:Uu5g05.Utils.Element.create("div",null,Uu5g05.Utils.Element.create(O().CancelButton,{onClick:()=>d(!1,0)
}),Uu5g05.Utils.Element.create(O().SubmitButton,null))},Uu5g05.Utils.Element.create(O().FormText,{initialValue:"list.name",name:"name",label:"Změn jméno"}))),Uu5g05.Utils.Element.create(te,null))))}
}),ke=(0,a.createComponent)({uu5Tag:B.TAG+"SItemListProvider",propTypes:{},defaultProps:{},render(e){console.log("SITEMS-PROVIDER",e);const{children:t}=e,[n,s]=(0,a.useState)(!1),[l,o]=(0,
a.useState)(!1),[u,c]=(0,a.useState)("");console.log("100deleted",l),console.log("110datalistState",u);const d=(0,a.useDataList)({handlerMap:{load:function(){return console.log("340datalist"),
i.Z.loadSlistsList()},create:function(e){return console.log("340datalist"),i.Z.createSlist(e)}},itemHandlerMap:{delete:m,isArchive:p}});async function m(e){console.log("handleDataListDelete",e)
;let t=await i.Z.deleteSlist(e);return console.log(t),d.handlerMap.load(),t}async function p(e){console.log("handleSsArchive",e);let t=await i.Z.updateSlist(e);return console.log(t),
d.handlerMap.load(),t}let g;switch(console.log("320datalist",d),console.log("datalist",d),d.state){case"pendingNoData":g=Uu5g05.Utils.Element.create(r().Pending,{size:"max"});break;case"errorNoData":
g=Uu5g05.Utils.Element.create(r().Alert,{header:"Cannot create library.",priority:"error"});break;case"error":g=Uu5g05.Utils.Element.create(r().Alert,{header:"Data about libraries cannot be loaded.",
priority:"error"});break;default:g=Uu5g05.Utils.Element.create(Ce,{data:d.data,setData:l,onCreate:d.handlerMap.create,onDelete:m,onUpdates:p}),console.log("400READYFUNCTION",d.data)}return g}
}),ye=()=>h.Z.Css.css({});let be=(0,a.createVisualComponent)({uu5Tag:h.Z.TAG+"Slist",propTypes:{},defaultProps:{},render(e){console.log("SLISTS-ROUTE",e);const{identity:t}=(0,
a.useSession)(),n=a.Utils.VisualComponent.getAttrs(e,ye())
;return Uu5g05.Utils.Element.create("div",n,Uu5g05.Utils.Element.create(g.Z,null),Uu5g05.Utils.Element.create(ke,null,Uu5g05.Utils.Element.create(Ce,{initialProducts:Te,initialList:Se[0]}),";"))}})
;const Se=[{id:a.Utils.String.generateId(),name:"Páteční nákup",archive:!1,childId:[156,142,186]}],Te=[{id:a.Utils.String.generateId(),name:"Apple",amount:5,unit:"Kg",active:!1},{
id:a.Utils.String.generateId(),name:"Car",amount:4,unit:"pieces",active:!1},{id:a.Utils.String.generateId(),name:"Knife",amount:5,unit:"pieces",active:!1},{id:a.Utils.String.generateId(),
name:"Orange",amount:10,unit:"Stock",active:!0},{id:a.Utils.String.generateId(),name:"Pumpkin",amount:4,unit:"Stock",active:!1},{id:a.Utils.String.generateId(),name:"Peas",amount:5,unit:"Kg",active:!0
}];be=(0,c.withRoute)(be,{authenticated:!1});const Ae=be,Le=()=>h.Z.Css.css({});let xe=(0,a.createVisualComponent)({uu5Tag:h.Z.TAG+"Slists",propTypes:{},defaultProps:{},render(e){const{identity:t}=(0,
a.useSession)(),n=a.Utils.VisualComponent.getAttrs(e,Le());return Uu5g05.Utils.Element.create("div",n,Uu5g05.Utils.Element.create(fe,null))}});xe=(0,c.withRoute)(xe,{authenticated:!1});const _e=xe
;var we=n(722);const Pe=(0,a.createComponent)({uu5Tag:U.Z.TAG+"ProviderPermission",propTypes:{},defaultProps:{},render(e){const t=(0,a.useDataObject)({handlerMap:{load:i.Z.Slists.load}})
;return Uu5g05.Utils.Element.create(we.ZP.Provider,{value:t},"function"==typeof e.children?e.children(t):e.children)}
}),Ie=a.Utils.Component.lazy((()=>n.e(701).then(n.bind(n,701)))),je=a.Utils.Component.lazy((()=>n.e(327).then(n.bind(n,327)))),Ne=a.Utils.Component.lazy((()=>n.e(180).then(n.bind(n,180)))),Me={"":{
redirect:"home"},home:e=>Uu5g05.Utils.Element.create(L,e),slist:e=>Uu5g05.Utils.Element.create(Ae,e),slists:e=>Uu5g05.Utils.Element.create(_e,e),about:e=>Uu5g05.Utils.Element.create(Ie,e),
"sys/uuAppWorkspace/initUve":e=>Uu5g05.Utils.Element.create(je,e),controlPanel:e=>Uu5g05.Utils.Element.create(Ne,e),"*":()=>Uu5g05.Utils.Element.create(r().Text,{category:"story",segment:"heading",
type:"h1"},"Not Found")};function Ze({children:e}){switch((0,a.useSession)().state){case"pending":return Uu5g05.Utils.Element.create(c.SpaPending,null);case"notAuthenticated":
return Uu5g05.Utils.Element.create(m.Unauthenticated,null);default:return e}}const De=(0,a.createVisualComponent)({uu5Tag:U.Z.TAG+"Spa",propTypes:{},defaultProps:{},
render:()=>Uu5g05.Utils.Element.create(u().SpaProvider,{initialLanguageList:["en","cs"],skipAppWorkspaceProvider:!0
},Uu5g05.Utils.Element.create(r().ModalBus,null,Uu5g05.Utils.Element.create(d().Spa,null,Uu5g05.Utils.Element.create(Ze,null,Uu5g05.Utils.Element.create(Pe,null,(e=>Uu5g05.Utils.Element.create(Uu5g05.Fragment,null,"pendingNoData"===e.state&&Uu5g05.Utils.Element.create(c.SpaPending,null),"errorNoData"===e.state&&Uu5g05.Utils.Element.create(c.Error,{
error:e.errorData}),["ready","pending","error"].includes(e.state)&&Uu5g05.Utils.Element.create(Uu5g05.Fragment,null,Uu5g05.Utils.Element.create(g.Z,null),Uu5g05.Utils.Element.create(d().Spa,{
routeMap:Me})))))))))});if(a.Environment.appVersion="0.1.0",!navigator.userAgent.match(/iPhone|iPad|iPod/)){let e=document.createElement("link");e.rel="manifest",e.href="assets/manifest.json",
document.head.appendChild(e)}let ze;function Be(e){ze=e,a.Utils.Dom.render(Uu5g05.Utils.Element.create(s.AppContainer,null,Uu5g05.Utils.Element.create(De,null)),document.getElementById(e))}},
426:(e,t,n)=>{"use strict";n.d(t,{Z:()=>r});var s=n(94),a=n(823);const i="uu_jokes_maing01-hi",l=e=>n(394)(`./${e}.json`);l.libraryCode=i,s.Utils.Lsi.setDefaultLsi(i,{en:a});const r=l},24:(e,t,n)=>{
"use strict";n.d(t,{Z:()=>l});var s=n(94),a=n(12);const i=a.Z.TAG+"Routes.",l={...a.Z,TAG:i,
Css:s.Utils.Css.createCssModule(i.replace(/\.$/,"").toLowerCase().replace(/\./g,"-").replace(/[^a-z-]/g,""),"uu_jokes_maing01-hi/uu_jokes_maing01-hi@0.1.0")}},332:e=>{e.exports={
AppContainer:e=>e.children??null}},280:(e,t,n)=>{
var s=n(145),a="undefined"!=typeof document,i=((s?s.uri:a&&(document.currentScript||Array.prototype.slice.call(document.getElementsByTagName("script"),-1)[0]||{}).src)||"").toString(),l="/0.0.0/"
;(i=i.split(/\//).slice(0,-1).join("/")+"/").substr(-7)===l&&(i=i.substr(0,i.length-7)+"/0.1.0/"),n.p=i,e.exports=n(988);var r=e.exports
;r&&"object"==typeof r&&("version"in r||Object.defineProperty(r,"version",{configurable:!0,value:"0.1.0"}),"name"in r||Object.defineProperty(r,"name",{configurable:!0,
value:"uu_jokes_maing01-hi".split(/[\/\\]/).pop()}),"namespace"in r||Object.defineProperty(r,"namespace",{configurable:!0,value:"UuJokes"}))},394:(e,t,n)=>{var s={"./cs.json":[27,27],"./en.json":[823]
};function a(e){if(!n.o(s,e))return Promise.resolve().then((()=>{var t=new Error("Cannot find module '"+e+"'");throw t.code="MODULE_NOT_FOUND",t}));var t=s[e],a=t[0]
;return Promise.all(t.slice(1).map(n.e)).then((()=>n.t(a,19)))}a.keys=()=>Object.keys(s),a.id=394,e.exports=a},145:t=>{"use strict";t.exports=e},918:e=>{"use strict";e.exports=n},94:e=>{"use strict"
;e.exports=t},834:e=>{"use strict";e.exports=a},389:e=>{"use strict";e.exports=r},767:e=>{"use strict";e.exports=o},190:e=>{"use strict";e.exports=c},320:e=>{"use strict";e.exports=u},763:e=>{
"use strict";e.exports=s},781:e=>{"use strict";e.exports=i},923:e=>{"use strict";e.exports=l},119:e=>{function t(){return e.exports=t=Object.assign?Object.assign.bind():function(e){
for(var t=1;t<arguments.length;t++){var n=arguments[t];for(var s in n)Object.prototype.hasOwnProperty.call(n,s)&&(e[s]=n[s])}return e},e.exports.__esModule=!0,e.exports.default=e.exports,
t.apply(this,arguments)}e.exports=t,e.exports.__esModule=!0,e.exports.default=e.exports},823:e=>{"use strict"
;e.exports=JSON.parse('{"appName":"Application uuShopping","About":{"header":"About application uuShopping","creatorsHeader":"Application creators","termsOfUse":"Terms of use"},"AboutContent":{"content":"<uu5string/>Demo application is a template for developing new applications.","technologiesContent":"<uu5string/>Other used technologies: <Uu5Elements.Link href=\'http://www.w3schools.com/html/default.asp\' target=\'_blank\'>Html5</Uu5Elements.Link>, <Uu5Elements.Link href=\'http://www.w3schools.com/css/default.asp\' target=\'_blank\'>CSS</Uu5Elements.Link>, <Uu5Elements.Link href=\'http://www.w3schools.com/js/default.asp\' target=\'_blank\'>JavaScript</Uu5Elements.Link>, <Uu5Elements.Link href=\'http://getbootstrap.com\' target=\'_blank\'>Bootstrap</Uu5Elements.Link>, <Uu5Elements.Link href=\'https://reactjs.org\' target=\'_blank\'>React</Uu5Elements.Link>, <Uu5Elements.Link href=\'https://www.ruby-lang.org\' target=\'_blank\'>Ruby</Uu5Elements.Link>, <Uu5Elements.Link href=\'http://puma.io\' target=\'_blank\'>Puma</Uu5Elements.Link> a <Uu5Elements.Link href=\'https://www.docker.com\' target=\'_blank\'>Docker</Uu5Elements.Link>. Application is operated in the <Uu5Elements.Link href=\'https://plus4u.net\' target=\'_blank\'>Plus4U</Uu5Elements.Link> internet service with the usage of <Uu5Elements.Link href=\'https://azure.microsoft.com\' target=\'_blank\'>Microsoft Azure</Uu5Elements.Link> cloud."},"ControlPanel":{"rightsError":"You do not have sufficient rights to display this component.","btNotConnected":"The application is not connected to a Business Territory."},"Home":{"welcome":"Welcome","intro":"<uu5string/>This template consist of prepared client and server side. Shown components demonstrate possibilities and way of using. For application developing purposes they are suitable for modifying, copying and deleting. More about uuApp Structure see documentation&nbsp; <Uu5Elements.Link href=\\"https://uuapp.plus4u.net/uu-bookkit-maing01/e884539c8511447a977c7ff070e7f2cf/book/page?code=stepByStepApp\\" target=\\"_blank\\">uuAppDevKit</Uu5Elements.Link>.","clientSide":"<uu5string/>Libraries <Uu5Elements.Link href=\\"https://uuapp.plus4u.net/uu-bookkit-maing01/05ecbf4e8bca405290b1a6d4cee8813a/book\\" target=\\"_blank\\">uu5</Uu5Elements.Link> and <Uu5Elements.Link href=\\"https://uuapp.plus4u.net/uu-bookkit-maing01/83c1406c4fc541dba975941424106318/book\\" target=\\"_blank\\">uuPlus4U5</Uu5Elements.Link> are used for developing of client side.","serverSide":"<uu5string/>It is necessary to initialize application workspace for running server side. See manual <Uu5Elements.Link href=\\"https://uuapp.plus4u.net/uu-bookkit-maing01/e884539c8511447a977c7ff070e7f2cf/book/page?code=stepByStepApp\\" target=\\"_blank\\">uuApp Template Developer Guide</Uu5Elements.Link>"},"InitAppWorkspace":{"notAuthorized":"You do not have sufficient rights to use the application.","formHeader":"Initialize uuApp","formHeaderInfo":"<uu5string/>Your uuApp is running, but requires initialization. If you need help with filling up this form, see\\n<Uu5Elements.Link target=\\"_blank\\" href=\\"#\\">Documentation</Uu5Elements.Link>.","notAuthorizedForInit":"The application is running but it was not initialized yet and you do not have sufficient rights to do so.","uuBtLocationUriLabel":"uuBusinessTerritory location","uuBtLocationUriInfo":"Uri of the uuBt location where AWSC will be created","nameLabel":"Name","initialize":"Initialize"},"Menu":{"home":"Welcome","slist":"Shopping list","slists":"Lists","about":"About Application"}}')
}},h={};function f(e){var t=h[e];if(void 0!==t)return t.exports;var n=h[e]={exports:{}};return U[e](n,n.exports,f),n.exports}return f.m=U,f.n=e=>{var t=e&&e.__esModule?()=>e.default:()=>e
;return f.d(t,{a:t}),t},m=Object.getPrototypeOf?e=>Object.getPrototypeOf(e):e=>e.__proto__,f.t=function(e,t){if(1&t&&(e=this(e)),8&t)return e;if("object"==typeof e&&e){if(4&t&&e.__esModule)return e
;if(16&t&&"function"==typeof e.then)return e}var n=Object.create(null);f.r(n);var s={};d=d||[null,m({}),m([]),m(m)]
;for(var a=2&t&&e;"object"==typeof a&&!~d.indexOf(a);a=m(a))Object.getOwnPropertyNames(a).forEach((t=>s[t]=()=>e[t]));return s.default=()=>e,f.d(n,s),n},f.d=(e,t)=>{
for(var n in t)f.o(t,n)&&!f.o(e,n)&&Object.defineProperty(e,n,{enumerable:!0,get:t[n]})},f.f={},f.e=e=>Promise.all(Object.keys(f.f).reduce(((t,n)=>(f.f[n](e,t),t)),[])),f.u=e=>"chunks/index/"+e+"-"+{
27:"ed82f5d405b531bddf3b",180:"787c76f55ea63a5b9001",327:"a5ea7da6114814e39c61",701:"a691151c06c51490ad76"}[e]+".min.js",f.o=(e,t)=>Object.prototype.hasOwnProperty.call(e,t),p={},g="[name]_0_1_0:",
f.l=(e,t,n,s)=>{if(p[e])p[e].push(t);else{var a,i;if(void 0!==n)for(var l=document.getElementsByTagName("script"),r=0;r<l.length;r++){var o=l[r]
;if(o.getAttribute("src")==e||o.getAttribute("data-webpack")==g+n){a=o;break}}a||(i=!0,(a=document.createElement("script")).charset="utf-8",a.timeout=120,f.nc&&a.setAttribute("nonce",f.nc),
a.setAttribute("data-webpack",g+n),a.src=e,0!==a.src.indexOf(window.location.origin+"/")&&(a.crossOrigin="anonymous")),p[e]=[t];var u=(t,n)=>{a.onerror=a.onload=null,clearTimeout(c);var s=p[e]
;if(delete p[e],a.parentNode&&a.parentNode.removeChild(a),s&&s.forEach((e=>e(n))),t)return t(n)},c=setTimeout(u.bind(null,void 0,{type:"timeout",target:a}),12e4);a.onerror=u.bind(null,a.onerror),
a.onload=u.bind(null,a.onload),i&&document.head.appendChild(a)}},f.r=e=>{"undefined"!=typeof Symbol&&Symbol.toStringTag&&Object.defineProperty(e,Symbol.toStringTag,{value:"Module"}),
Object.defineProperty(e,"__esModule",{value:!0})},f.p="",(()=>{var e={826:0};f.f.j=(t,n)=>{var s=f.o(e,t)?e[t]:void 0;if(0!==s)if(s)n.push(s[2]);else{var a=new Promise(((n,a)=>s=e[t]=[n,a]))
;n.push(s[2]=a);var i=f.p+f.u(t),l=new Error;f.l(i,(n=>{if(f.o(e,t)&&(0!==(s=e[t])&&(e[t]=void 0),s)){var a=n&&("load"===n.type?"missing":n.type),i=n&&n.target&&n.target.src
;l.message="Loading chunk "+t+" failed.\n("+a+": "+i+")",l.name="ChunkLoadError",l.type=a,l.request=i,s[1](l)}}),"chunk-"+t,t)}};var t=(t,n)=>{var s,a,[i,l,r]=n,o=0;if(i.some((t=>0!==e[t]))){
for(s in l)f.o(l,s)&&(f.m[s]=l[s]);if(r)r(f)}for(t&&t(n);o<i.length;o++)a=i[o],f.o(e,a)&&e[a]&&e[a][0](),e[a]=0
},n=this.__webpack_jsonp_uu_jokes_maing01_hi_0_1_0_index=this.__webpack_jsonp_uu_jokes_maing01_hi_0_1_0_index||[];n.forEach(t.bind(null,0)),n.push=t.bind(null,n.push.bind(n))})(),f(280)})()));